// ====================================================
// MODULE 4: ACCURATE REAL-TIME PROGRESS & ANALYTICS ENGINE
// ====================================================

function getAccurateProgressMetrics() {
    const routine = typeof getRoutineData === 'function' ? getRoutineData() : {
        morning_brain: false,
        hydration: false,
        water_count: 0,
        walk: false,
        afternoon_puzzle: false,
        evening_audio: false
    };

    // 1. Routine Tasks (5 total)
    let routineCompleted = 0;
    if (routine.morning_brain) routineCompleted++;
    if (routine.hydration) routineCompleted++;
    if (routine.walk) routineCompleted++;
    if (routine.afternoon_puzzle) routineCompleted++;
    if (routine.evening_audio) routineCompleted++;

    // 2. Hydration: Goal is 6 glasses
    const waterGoal = 6;
    const waterCompleted = Math.min(waterGoal, routine.water_count || 0);

    // 3. Mobility: Goal is 1 walk session (10 mins)
    const walkGoal = 1;
    const walkCompleted = routine.walk ? 1 : 0;

    // 4. Cognitive Domains:
    let scores = {};
    try {
        scores = JSON.parse(localStorage.getItem('gameScores')) || {};
    } catch(e) { scores = {}; }

    // Family Therapy quiz count
    const familyPlayed = (typeof familyQuizCount !== 'undefined' && familyQuizCount > 0) ? Math.min(4, familyQuizCount) : 0;

    // Cognitive Domain Breakdown:
    // Memory: Morning brain + Sequence(0), Grid(1), N-Back(7), Old/New(10), Recall(11)
    const memTasksTotal = 3;
    let memTasksDone = 0;
    if (routine.morning_brain) memTasksDone++;
    if (scores[0] !== undefined || scores[1] !== undefined) memTasksDone++;
    if (scores[10] !== undefined || scores[11] !== undefined) memTasksDone++;
    memTasksDone = Math.min(memTasksTotal, memTasksDone);

    // Attention & Speed: Target(2), Switch(3), Go/No-Go(8)
    const attTasksTotal = 2;
    let attTasksDone = 0;
    if (scores[2] !== undefined || scores[3] !== undefined) attTasksDone++;
    if (scores[8] !== undefined) attTasksDone++;
    attTasksDone = Math.min(attTasksTotal, attTasksDone);

    // Reasoning & Logic: Match(4), Pattern(5), Matrix(6), Rule(9), Order(12)
    const reasTasksTotal = 2;
    let reasTasksDone = 0;
    if (routine.afternoon_puzzle || scores[4] !== undefined) reasTasksDone++;
    if (scores[5] !== undefined || scores[6] !== undefined || scores[12] !== undefined) reasTasksDone++;
    reasTasksDone = Math.min(reasTasksTotal, reasTasksDone);

    // Family & Social Reminiscence:
    const famTasksTotal = 2;
    let famTasksDone = 0;
    if (familyPlayed >= 1) famTasksDone++;
    if (familyPlayed >= 3) famTasksDone++;

    // Audio Therapy & Relaxation:
    const audioTasksTotal = 1;
    const audioTasksDone = routine.evening_audio ? 1 : 0;

    // Overall Adherence Percentage (Accurately computed from 5 daily routine tasks):
    const overallPct = Math.min(100, Math.round((routineCompleted / 5) * 100));

    return {
        routineCompleted,
        routineTotal: 5,
        waterCompleted,
        waterGoal,
        walkCompleted,
        walkGoal,
        overallPct,
        cognitive: {
            "Memory & Recall": { done: memTasksDone, total: memTasksTotal },
            "Attention & Reflexes": { done: attTasksDone, total: attTasksTotal },
            "Reasoning & Executive Logic": { done: reasTasksDone, total: reasTasksTotal },
            "Family & Face Recognition": { done: famTasksDone, total: famTasksTotal },
            "Calming Audio & Breathing": { done: audioTasksDone, total: audioTasksTotal }
        }
    };
}

function updateProgressUI() {
    const metrics = getAccurateProgressMetrics();

    // 1. Home Screen Progress Widget
    const homeFill = document.getElementById('home-progress-fill');
    const homePct = document.getElementById('home-progress-pct');
    if (homeFill) {
        homeFill.style.width = `${metrics.overallPct}%`;
        homeFill.style.background = metrics.overallPct >= 80 ? '#4CAF50' : (metrics.overallPct >= 40 ? '#FFC107' : '#FF8A65');
    }
    if (homePct) {
        homePct.innerText = `${metrics.overallPct}% (${metrics.routineCompleted} / ${metrics.routineTotal} Tasks)`;
    }

    // 2. Routine Screen Progress Widget
    const rBar = document.getElementById('routine-progress-bar');
    const rText = document.getElementById('routine-progress-text');
    if (rBar) rBar.style.width = `${metrics.overallPct}%`;
    if (rText) rText.innerText = `${metrics.routineCompleted} / ${metrics.routineTotal} Completed`;
}

function renderProgressTab() {
    const metrics = getAccurateProgressMetrics();
    updateProgressUI();

    const overallPct = metrics.overallPct;

    let themeColor = '';
    if (overallPct < 40) {
        themeColor = '#FF8A65';
    } else if (overallPct <= 70) {
        themeColor = '#FFC107';
    } else {
        themeColor = '#4CAF50';
    }

    // 1. Hero Circular Ring
    const ring = document.getElementById('overall-ring');
    if (ring) {
        const radius = ring.r.baseVal.value || 70;
        const circumference = radius * 2 * Math.PI;
        ring.style.strokeDasharray = `${circumference} ${circumference}`;
        const offset = circumference - (overallPct / 100) * circumference;
        ring.style.strokeDashoffset = offset;
        ring.style.stroke = themeColor;
        ring.style.transition = 'stroke-dashoffset 0.6s ease-out, stroke 0.4s ease';
    }

    const pctText = document.getElementById('overall-percentage');
    if (pctText) {
        pctText.innerText = `${overallPct}%`;
        pctText.style.color = themeColor;
    }

    // 2. Physical & Routine Cards
    const hydText = document.getElementById('hyd-text');
    const hydBar = document.getElementById('hyd-bar');
    if (hydText) hydText.innerText = `${metrics.waterCompleted} / ${metrics.waterGoal} Glasses`;
    if (hydBar) {
        const hydPct = (metrics.waterCompleted / metrics.waterGoal) * 100;
        hydBar.style.width = `${hydPct}%`;
        hydBar.style.background = '#0288D1';
        hydBar.style.transition = 'width 0.5s ease-out';
    }

    const mobText = document.getElementById('mob-text');
    const mobBar = document.getElementById('mob-bar');
    if (mobText) mobText.innerText = `${metrics.walkCompleted} / ${metrics.walkGoal} Session`;
    if (mobBar) {
        const mobPct = (metrics.walkCompleted / metrics.walkGoal) * 100;
        mobBar.style.width = `${mobPct}%`;
        mobBar.style.background = '#FF9800';
        mobBar.style.transition = 'width 0.5s ease-out';
    }

    // 3. Cognitive Domain Breakdown
    const cogContainer = document.getElementById('cognitive-progress-list');
    if (cogContainer) {
        cogContainer.innerHTML = '';
        for (let cat in metrics.cognitive) {
            const item = metrics.cognitive[cat];
            const pct = item.total === 0 ? 0 : Math.round((item.done / item.total) * 100);
            const card = document.createElement('div');
            card.className = 'progress-card';
            card.style.background = 'white';
            card.style.borderRadius = '14px';
            card.style.padding = '14px 16px';
            card.style.marginBottom = '12px';
            card.style.boxShadow = '0 2px 6px rgba(0,0,0,0.05)';
            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <span style="font-weight: 700; font-size: 14px; color: #37474F;">${cat}</span>
                    <span style="font-size: 13px; font-weight: 700; color: ${pct >= 100 ? '#4CAF50' : '#00796B'};">${item.done} / ${item.total}</span>
                </div>
                <div class="bar-bg" style="width: 100%; height: 8px; background: #eee; border-radius: 4px; overflow: hidden;">
                    <div style="width: ${pct}%; height: 100%; background: ${pct >= 100 ? '#4CAF50' : (pct >= 50 ? '#00796B' : '#FF9800')}; border-radius: 4px; transition: 0.5s ease-out;"></div>
                </div>
            `;
            cogContainer.appendChild(card);
        }
    }
}
