var gauntletInterval = null;
var gauntletTimeLeft = 300;
var currentPhase = 0;
window.savedRecallItems = [];
window.gauntletTasksQueue = [];

function startAssessment() {
    showScreen('assessment-screen');
    gauntletTimeLeft = 300;
    currentPhase = 0;
    window.savedRecallItems = [];
    
    // Shuffle 13 games
    window.gauntletTasksQueue = [0,1,2,3,4,5,6,7,8,9,10,11,12].sort(() => Math.random() - 0.5);
    let recallIdx = window.gauntletTasksQueue.indexOf(11);
    if (recallIdx < 5) {
        let swap = window.gauntletTasksQueue[12];
        window.gauntletTasksQueue[12] = 11;
        window.gauntletTasksQueue[recallIdx] = swap;
    }

    document.getElementById('gauntlet-timer').innerText = '05:00';
    document.getElementById('gauntlet-progress').style.width = '0%';
    
    const area = document.getElementById('gauntlet-area');
    if(!document.getElementById('demo-skip')) {
        const skipBtn = document.createElement('button');
        skipBtn.id = 'demo-skip';
        skipBtn.innerText = 'Skip to Results (Demo Mode)';
        skipBtn.style.position = 'absolute'; skipBtn.style.bottom = '10px'; skipBtn.style.background = 'transparent';
        skipBtn.style.border = 'none'; skipBtn.style.textDecoration = 'underline'; skipBtn.style.color = '#999';
        skipBtn.onclick = finishAssessment;
        document.getElementById('assessment-screen').appendChild(skipBtn);
    }
    
    clearInterval(gauntletInterval);
    gauntletInterval = setInterval(() => {
        gauntletTimeLeft--;
        let m = Math.floor(gauntletTimeLeft / 60).toString().padStart(2, '0');
        let s = (gauntletTimeLeft % 60).toString().padStart(2, '0');
        document.getElementById('gauntlet-timer').innerText = m + ':' + s;
        
        let pct = ((300 - gauntletTimeLeft) / 300) * 100;
        document.getElementById('gauntlet-progress').style.width = pct + '%';

        if (gauntletTimeLeft <= 0) {
            clearInterval(gauntletInterval);
            finishAssessment();
        }
    }, 1000);

    loadNextGauntletTask();
}

function loadNextGauntletTask() {
    if (gauntletTimeLeft <= 0) return;
    const area = document.getElementById('gauntlet-area');
    area.innerHTML = ''; 
    
    if (window.gauntletTasksQueue.length === 0) {
        finishAssessment();
        return;
    }

    let taskType = window.gauntletTasksQueue.shift();
    currentPhase++; 

    let level = 1; let levelText = 'Level 1: Easy';
    if (currentPhase > 4 && currentPhase <= 9) {
        level = 2; levelText = 'Level 2: Medium';
    } else if (currentPhase > 9) {
        level = 3; levelText = 'Level 3: Hard';
    }
    
    const badge = document.createElement('div');
    badge.innerText = levelText;
    badge.style.padding = '4px 8px'; 
    badge.style.background = level === 1 ? '#4CAF50' : level === 2 ? '#FF9800' : '#F44336';
    badge.style.color = 'white'; badge.style.borderRadius = '8px'; badge.style.fontSize = '14px'; badge.style.fontWeight = 'bold';
    badge.style.marginBottom = '15px';
    badge.style.display = 'inline-block';
    area.appendChild(badge);

    const titleEl = document.getElementById('gauntlet-title');

    const emj = {
        fruits: ['&#x1F34E;','&#x1F34C;','&#x1F347;','&#x1F353;','&#x1F34A;'],
        shapes: ['&#x1F534;','&#x1F7E2;','&#x1F7E1;','&#x1F535;','&#x1F7E3;'],
        animals: ['&#x1F436;','&#x1F431;','&#x1F42D;','&#x1F430;','&#x1F43B;'],
        weather: ['&#x2600;&#xFE0F;','&#x1F327;&#xFE0F;','&#x26C4;','&#x1F308;','&#x26A1;']
    };

    function makeGrid(items, onSelect) {
        const grid = document.createElement('div');
        grid.style.display = 'grid'; 
        grid.style.gridTemplateColumns = items.length <= 4 ? 'repeat(2, 1fr)' : 'repeat(3, 1fr)'; 
        grid.style.gap = '15px'; 
        grid.style.marginTop = '20px';
        grid.style.width = '100%';
        grid.style.maxWidth = '400px';
        items.forEach(obj => {
            const btn = document.createElement('button'); btn.innerHTML = obj; 
            btn.style.padding = '15px'; btn.style.fontSize = '35px'; 
            btn.style.borderRadius = '12px'; btn.style.border = '2px solid #ccc'; 
            btn.style.background = 'white'; btn.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            btn.style.cursor = 'pointer';
            btn.onclick = () => onSelect(obj, btn);
            grid.appendChild(btn);
        });
        area.appendChild(grid);
    }
    
    function makeInst(text) {
        const inst = document.createElement('p'); inst.innerHTML = text; inst.style.fontSize = '20px'; inst.style.fontWeight = '600'; inst.style.color = '#37474F'; inst.style.textAlign = 'center'; area.appendChild(inst);
    }

    if (taskType === 0) {
        titleEl.innerText = 'Game 1: Sequence Memory (AD/LBD)';
        let seqLen = level === 1 ? 3 : 4; // user requested max 4 items for level 3
        let speed = level === 1 ? 2000 : level === 2 ? 1600 : 1300;
        let pool = emj.shapes;
        let seq = [];
        for(let i=0; i<seqLen; i++) seq.push(pool[Math.floor(Math.random()*pool.length)]);
        window.savedRecallItems.push(seq[0]); 
        
        makeInst('Watch the sequence...');
        const disp = document.createElement('h2'); disp.style.fontSize = '80px'; disp.style.margin = '30px 0'; area.appendChild(disp);
        
        let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            if(step < seqLen) {
                disp.innerHTML = seq[step];
                setTimeout(() => { disp.innerHTML = ''; }, speed - 300);
                step++;
            } else {
                clearInterval(intv);
                area.innerHTML = ''; area.appendChild(badge); makeInst('Tap the sequence in order:');
                let userSeq = [];
                makeGrid(pool, (val, btn) => {
                    userSeq.push(val);
                    btn.style.background = '#E0F2F1';
                    if(userSeq.length === seqLen) setTimeout(loadNextGauntletTask, 300);
                });
            }
        }, speed);
    }
    else if (taskType === 1) {
        titleEl.innerText = 'Game 2: Grid Memory (AD)';
        let count = level === 1 ? 3 : 4; // user requested max 4
        makeInst('Remember the green squares');
        
        const grid = document.createElement('div');
        grid.style.display = 'grid'; grid.style.gridTemplateColumns = 'repeat(3, 1fr)'; grid.style.gap = '15px'; grid.style.margin = '30px auto'; grid.style.width = '240px'; grid.style.height = '240px';
        let cells = [];
        let active = [];
        for(let i=0; i<9; i++) {
            let c = document.createElement('div'); c.style.background = '#eee'; c.style.borderRadius = '12px'; c.style.boxShadow = 'inset 0 0 5px rgba(0,0,0,0.1)';
            grid.appendChild(c); cells.push(c);
        }
        area.appendChild(grid);
        
        while(active.length < count) {
            let r = Math.floor(Math.random()*9);
            if(!active.includes(r)) active.push(r);
        }
        
        active.forEach(idx => cells[idx].style.background = '#00796B');
        
        setTimeout(() => {
            if(gauntletTimeLeft <= 0) return;
            cells.forEach(c => c.style.background = '#eee');
            makeInst('Tap the squares that were green');
            let found = 0;
            cells.forEach((c, idx) => {
                c.onclick = () => {
                    if(active.includes(idx)) { c.style.background = '#4CAF50'; found++; }
                    else { c.style.background = '#F44336'; }
                    if(found === count) setTimeout(loadNextGauntletTask, 500);
                }
            });
        }, level === 1 ? 4000 : level === 2 ? 3000 : 2500);
    }
    else if (taskType === 2) {
        titleEl.innerText = 'Game 3: Target Detection (FTD/VCI)';
        makeInst('Tap the Blue Circle (&#x1F535;) as soon as it appears!');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '40px 0'; box.style.fontSize = '80px'; area.appendChild(box);
        let reps = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let isTarget = Math.random() < 0.3 || reps === 3;
            box.innerHTML = isTarget ? '&#x1F535;' : '&#x1F7E2;';
            box.onclick = () => {
                if(isTarget) { clearInterval(intv); box.style.background = '#E8F5E9'; box.style.borderRadius = '50%'; setTimeout(loadNextGauntletTask, 500); }
            };
            reps++;
            if (reps > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 1500 : level === 2 ? 1200 : 1000);
        }, level === 1 ? 2500 : level === 2 ? 2000 : 1500);
    }
    else if (taskType === 3) {
        titleEl.innerText = 'Game 4: Attention Switching (FTD)';
        makeInst(level === 1 ? 'If EVEN tap Left, If ODD tap Right' : 'If RED tap Left, If BLUE tap Right');
        
        let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; area.appendChild(target);
        let val = level === 1 ? Math.floor(Math.random()*8)+2 : (Math.random() > 0.5 ? '&#x1F534;' : '&#x1F535;');
        target.innerHTML = val;
        
        const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
        let btnL = document.createElement('button'); btnL.innerText = 'LEFT'; btnL.style.padding = '25px'; btnL.style.fontSize = '24px'; btnL.style.flex = '1'; btnL.style.borderRadius = '16px'; btnL.style.border = '2px solid #ccc'; btnL.onclick = loadNextGauntletTask;
        let btnR = document.createElement('button'); btnR.innerText = 'RIGHT'; btnR.style.padding = '25px'; btnR.style.fontSize = '24px'; btnR.style.flex = '1'; btnR.style.borderRadius = '16px'; btnR.style.border = '2px solid #ccc'; btnR.onclick = loadNextGauntletTask;
        flex.appendChild(btnL); flex.appendChild(btnR); area.appendChild(flex);
    }
    else if (taskType === 4) {
        titleEl.innerText = 'Game 5: Quick Match (LBD/PD)';
        makeInst('Find the matching animal:');
        
        const targetDisp = document.createElement('div');
        targetDisp.innerHTML = '&#x1F431;'; // Cat
        targetDisp.style.fontSize = '60px';
        targetDisp.style.margin = '10px 0';
        area.appendChild(targetDisp);

        let count = level === 1 ? 4 : level === 2 ? 6 : 9;
        let pool = emj.animals.slice();
        let items = ['&#x1F431;'];
        while(items.length < count) {
            items.push(pool[Math.floor(Math.random()*pool.length)]);
        }
        items.sort(() => Math.random() - 0.5);
        makeGrid(items, (val) => {
            if(val === '&#x1F431;') loadNextGauntletTask();
        });
    }
    else if (taskType === 5) {
        titleEl.innerText = 'Game 6: Pattern Completion (AD/VCI)';
        makeInst('What number comes next?');
        let pat = level === 1 ? [2, 4, 6, 8] : level === 2 ? [5, 10, 15, 20] : [1, 2, 4, 8];
        let ans = level === 1 ? 10 : level === 2 ? 25 : 16;
        let pText = document.createElement('h2'); pText.innerText = pat.join(', ') + ', ?'; pText.style.margin = '30px 0'; pText.style.letterSpacing = '2px'; pText.style.color = '#00796B'; area.appendChild(pText);
        
        let opts = [ans, ans+1, ans-1, ans+2].sort(() => Math.random()-0.5);
        makeGrid(opts, (val) => { loadNextGauntletTask(); });
    }
    else if (taskType === 6) {
        titleEl.innerText = 'Game 7: Matrix Reasoning (AD)';
        makeInst('Complete the logic:');
        let pText = document.createElement('h2'); pText.innerHTML = '&#x2600;&#xFE0F; -> &#x1F305; <br><br> &#x1F319; -> ?'; pText.style.margin = '30px 0'; pText.style.fontSize = '40px'; area.appendChild(pText);
        
        let opts = ['&#x1F30C;', '&#x1F327;&#xFE0F;', '&#x26C4;', '&#x1F308;'].sort(() => Math.random()-0.5);
        makeGrid(opts, (val) => { loadNextGauntletTask(); });
    }
    else if (taskType === 7) {
        titleEl.innerText = 'Game 8: N-Back Memory (FTD/VCI)';
        makeInst('Tap Match if the current shape is EXACTLY the same as the PREVIOUS shape.');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '20px 0'; box.style.fontSize = '80px'; area.appendChild(box);
        
        let btn = document.createElement('button'); btn.innerText = 'MATCH!'; btn.style.padding = '20px'; btn.style.width = '100%'; btn.style.maxWidth = '300px'; btn.style.fontSize = '24px'; btn.style.fontWeight = 'bold'; btn.style.borderRadius = '16px'; btn.style.border = '2px solid #ccc'; btn.style.background = 'white'; area.appendChild(btn);
        
        let pool = emj.shapes;
        let last = '';
        let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let cur = Math.random() < 0.4 && last !== '' ? last : pool[Math.floor(Math.random()*pool.length)];
            box.innerHTML = cur;
            btn.onclick = () => { if(cur === last) { clearInterval(intv); btn.style.background = '#C8E6C9'; setTimeout(loadNextGauntletTask, 500); } };
            last = cur;
            step++;
            if(step > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 2000 : 1500);
        }, level === 1 ? 3500 : 2500);
    }
    else if (taskType === 8) {
        titleEl.innerText = 'Game 9: Go/No-Go (FTD/PD)';
        makeInst('Tap GREEN (&#x1F7E2;). DO NOT tap RED (&#x1F534;).');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '40px 0'; box.style.fontSize = '100px'; box.style.cursor = 'pointer'; area.appendChild(box);
        let taps = 0; let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let isGreen = Math.random() > 0.4;
            box.innerHTML = isGreen ? '&#x1F7E2;' : '&#x1F534;';
            box.onclick = () => { if(isGreen) taps++; };
            step++;
            if(taps >= 3 || step > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 1500 : level === 2 ? 1200 : 1000);
        }, level === 1 ? 2500 : 1800);
    }
    else if (taskType === 9) {
        titleEl.innerText = 'Game 10: Rule Learning (FTD/PD)';
        let isReversed = level > 1;
        makeInst(isReversed ? 'Reverse Rule: Apple Right, Banana Left' : 'Rule: Apple Left, Banana Right');
        
        let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; area.appendChild(target);
        let val = Math.random() > 0.5 ? '&#x1F34E;' : '&#x1F34C;';
        target.innerHTML = val;
        
        const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
        let btnL = document.createElement('button'); btnL.innerText = 'LEFT'; btnL.style.padding = '25px'; btnL.style.fontSize = '24px'; btnL.style.flex = '1'; btnL.style.borderRadius = '16px'; btnL.style.border = '2px solid #ccc'; btnL.onclick = loadNextGauntletTask;
        let btnR = document.createElement('button'); btnR.innerText = 'RIGHT'; btnR.style.padding = '25px'; btnR.style.fontSize = '24px'; btnR.style.flex = '1'; btnR.style.borderRadius = '16px'; btnR.style.border = '2px solid #ccc'; btnR.onclick = loadNextGauntletTask;
        flex.appendChild(btnL); flex.appendChild(btnR); area.appendChild(flex);
    }
    else if (taskType === 10) {
        titleEl.innerText = 'Game 11: Memory Recognition (AD)';
        
        makeInst('Memorize these symbols...');
        const tempPool = ['&#x1F30E;', '&#x1F680;', '&#x1F3B2;', '&#x1F514;'];
        const disp = document.createElement('div');
        disp.innerHTML = tempPool.join(' &nbsp; ');
        disp.style.fontSize = '40px'; disp.style.margin = '30px 0';
        area.appendChild(disp);
        
        setTimeout(() => {
            if(gauntletTimeLeft <= 0) return;
            area.innerHTML = ''; area.appendChild(badge);
            makeInst('Did you just see this symbol?');
            let isOld = Math.random() > 0.5;
            let val = isOld ? tempPool[Math.floor(Math.random()*tempPool.length)] : '&#x1F381;';
            
            let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; target.innerHTML = val; area.appendChild(target);
            
            const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
            let btnO = document.createElement('button'); btnO.innerText = 'YES'; btnO.style.padding = '25px'; btnO.style.fontSize = '24px'; btnO.style.flex = '1'; btnO.style.borderRadius = '16px'; btnO.style.border = '2px solid #4CAF50'; btnO.onclick = loadNextGauntletTask;
            let btnN = document.createElement('button'); btnN.innerText = 'NO'; btnN.style.padding = '25px'; btnN.style.fontSize = '24px'; btnN.style.flex = '1'; btnN.style.borderRadius = '16px'; btnN.style.border = '2px solid #F44336'; btnN.onclick = loadNextGauntletTask;
            flex.appendChild(btnO); flex.appendChild(btnN); area.appendChild(flex);
        }, 3000);
    }
    else if (taskType === 11) {
        titleEl.innerText = 'Game 12: Delayed Recall (AD/MCI)';
        makeInst('Which shape was the very FIRST one you saw at the start?');
        let opts = emj.shapes.slice().sort(() => Math.random() - 0.5);
        makeGrid(opts, (val, btn) => { 
            btn.style.background = '#C8E6C9';
            setTimeout(loadNextGauntletTask, 500); 
        });
    }
    else if (taskType === 12) {
        titleEl.innerText = 'Game 13: Order Planning (VCI/PD)';
        makeInst('Tap the numbers from Smallest to Largest');
        let arr = [12, 45, 7, 89];
        if (level === 2) arr = [3, -5, 12, 0, 8];
        if (level === 3) arr = [105, 42, 99, 13, 76];
        let sorted = arr.slice().sort((a,b) => a-b);
        let currentIdx = 0;
        
        let shuffled = arr.slice().sort(() => Math.random() - 0.5);
        makeGrid(shuffled, (val, btn) => {
            if(val == sorted[currentIdx]) {
                btn.style.background = '#4CAF50'; btn.style.color = 'white';
                currentIdx++;
                if(currentIdx === arr.length) setTimeout(loadNextGauntletTask, 500);
            } else {
                btn.style.background = '#F44336'; btn.style.color = 'white';
            }
        });
    }
}

window.isSingleGame = false;
function startSingleGame(taskType) {
    showScreen('assessment-screen');
    window.savedRecallItems = ['&#x1F7E2;']; 
    gauntletTimeLeft = 9999;
    document.getElementById('gauntlet-timer').style.display = 'none';
    document.getElementById('gauntlet-progress').parentElement.style.display = 'none';
    
    window.gauntletTasksQueue = [taskType];
    window.isSingleGame = true;
    currentPhase = 8; 
    loadNextGauntletTask();
}

function quitAssessment() {
    window.isQuitting = true;
    if (typeof gauntletInterval !== 'undefined') clearInterval(gauntletInterval);
    gauntletTimeLeft = 0; // Signals local game intervals to terminate
    
    // Clear the active game area to prevent rogue clicks
    const area = document.getElementById('gauntlet-area');
    if(area) area.innerHTML = '';
    
    setTimeout(() => {
        if (window.isSingleGame) {
            window.isSingleGame = false;
            // Restore UI elements for next full assessment
            document.getElementById('gauntlet-timer').style.display = 'inline-block';
            document.getElementById('gauntlet-progress').parentElement.style.display = 'block';
            showScreen('game-menu-screen');
        } else {
            showScreen('home-screen');
        }
        window.isQuitting = false;
    }, 150);
}
