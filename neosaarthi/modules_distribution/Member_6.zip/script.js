let stats = { cog: 0, hyd: 0, phy: 0 };
const langData = {
    "en": { 
        label: "English", 
        changeLang: "Change Language",
        landing: { greeting: "Welcome", next: "Next" },
        login: { title: "Welcome", sub: "Enter details to continue", phone: "Phone Number (Required)*", email: "Email ID (Optional)", btn: "Send OTP" },
        otp: { title: "Verify Phone", sub: "OTP sent to your number", btn: "Verify & Secure" },
        role: { title: "Who is using this?", sub: "We will adapt the experience for you.", self_title: "Set up for myself", self_desc: "I want to maintain a healthy routine.", loved_title: "Set up for a loved one", loved_desc: "I am managing care for a family member." },
        home: { greeting: "Good Morning", btn1: "Play Game", btn2: "Family", btn3: "Routine", btn4: "SOS Alert" }
    },
    "as": { 
        label: "Assamese (à¦…à¦¸à¦®à§€à¦¯à¦¼à¦¾)", 
        changeLang: "à¦­à¦¾à¦·à¦¾ à¦¸à¦²à¦¨à¦¿ à¦•à§°à¦•",
        landing: { greeting: "à¦¸à§à¦¬à¦¾à¦—à¦¤à¦®", next: "à¦ªà§°à§±à§°à§à¦¤à§€" },
        login: { title: "à¦¸à§à¦¬à¦¾à¦—à¦¤à¦®", sub: "à¦†à¦—à¦¬à¦¾à¦¢à¦¼à¦¿à¦¬à¦²à§ˆ à¦¸à¦¬à¦¿à¦¶à§‡à¦· à¦¦à¦¿à¦¯à¦¼à¦•", phone: "à¦«à§‹à¦¨ à¦¨à¦®à§à¦¬à§° (à¦ªà§à§°à¦¯à¦¼à§‹à¦œà¦¨à§€à¦¯à¦¼)*", email: "à¦‡à¦®à§‡à¦‡à¦² (à¦¬à§ˆà¦•à¦²à§à¦ªà¦¿à¦•)", btn: "OTP à¦ªà¦ à¦¿à¦¯à¦¼à¦¾à¦“à¦•" },
        otp: { title: "à¦«à§‹à¦¨ à¦ªà§à§°à¦®à¦¾à¦£à¦¿à¦¤ à¦•à§°à¦•", sub: "à¦†à¦ªà§‹à¦¨à¦¾à§° à¦¨à¦®à§à¦¬à§°à¦²à§ˆ OTP à¦ªà¦ à¦¿à¦“à§±à¦¾ à¦¹à§ˆà¦›à§‡", btn: "à¦ªà§à§°à¦®à¦¾à¦£à¦¿à¦¤ à¦•à§°à¦•" },
        role: { title: "à¦•à§‹à¦¨à§‡ à¦¬à§à¦¯à§±à¦¹à¦¾à§° à¦•à§°à¦¿à¦›à§‡?", sub: "à¦†à¦®à¦¿ à¦†à¦ªà§‹à¦¨à¦¾à§° à¦¬à¦¾à¦¬à§‡ à¦…à¦­à¦¿à¦œà§à¦žà¦¤à¦¾ à¦¸à¦²à¦¨à¦¿ à¦•à§°à¦¿à¦®à¥¤", self_title: "à¦®à§‹à§° à¦¬à¦¾à¦¬à§‡ à¦›à§‡à¦Ÿ à¦†à¦ª à¦•à§°à¦•", self_desc: "à¦®à¦‡ à¦à¦Ÿà¦¾ à¦¸à§à¦¸à§à¦¥ à§°à§à¦Ÿà¦¿à¦¨ à¦¬à¦œà¦¾à¦‡ à§°à¦¾à¦–à¦¿à¦¬ à¦¬à¦¿à¦šà¦¾à§°à§‹à¥¤", loved_title: "à¦ªà§à§°à¦¿à¦¯à¦¼à¦œà¦¨à§° à¦¬à¦¾à¦¬à§‡ à¦›à§‡à¦Ÿ à¦†à¦ª à¦•à§°à¦•", loved_desc: "à¦®à¦‡ à¦ªà§°à¦¿à¦¯à¦¼à¦¾à¦²à§° à¦¸à¦¦à¦¸à§à¦¯à§° à¦¬à¦¾à¦¬à§‡ à¦¯à¦¤à¦¨ à¦ªà§°à¦¿à¦šà¦¾à¦²à¦¨à¦¾ à¦•à§°à¦¿ à¦†à¦›à§‹à¥¤" },
        home: { greeting: "à¦¸à§à¦ªà§à§°à¦­à¦¾à¦¤", btn1: "à¦–à§‡à¦² à¦–à§‡à¦²à¦•", btn2: "à¦ªà§°à¦¿à¦¯à¦¼à¦¾à¦²", btn3: "à§°à§à¦Ÿà¦¿à¦¨", btn4: "à¦œà§°à§à§°à§€à¦•à¦¾à¦²à§€à¦¨" }
    },
    "hi": { 
        label: "Hindi (à¤¹à¤¿à¤‚à¤¦à¥€)", 
        changeLang: "à¤­à¤¾à¤·à¤¾ à¤¬à¤¦à¤²à¥‡à¤‚",
        landing: { greeting: "à¤¨à¤®à¤¸à¥à¤¤à¥‡", next: "à¤…à¤—à¤²à¤¾" },
        login: { title: "à¤¸à¥à¤µà¤¾à¤—à¤¤ à¤¹à¥ˆ", sub: "à¤œà¤¾à¤°à¥€ à¤°à¤–à¤¨à¥‡ à¤•à¥‡ à¤²à¤¿à¤ à¤µà¤¿à¤µà¤°à¤£ à¤¦à¤°à¥à¤œ à¤•à¤°à¥‡à¤‚", phone: "à¤«à¥‹à¤¨ à¤¨à¤‚à¤¬à¤° (à¤†à¤µà¤¶à¥à¤¯à¤•)*", email: "à¤ˆà¤®à¥‡à¤² (à¤µà¥ˆà¤•à¤²à¥à¤ªà¤¿à¤•)", btn: "OTP à¤­à¥‡à¤œà¥‡à¤‚" },
        otp: { title: "à¤«à¥‹à¤¨ à¤¸à¤¤à¥à¤¯à¤¾à¤ªà¤¿à¤¤ à¤•à¤°à¥‡à¤‚", sub: "à¤†à¤ªà¤•à¥‡ à¤¨à¤‚à¤¬à¤° à¤ªà¤° OTP à¤­à¥‡à¤œà¤¾ à¤—à¤¯à¤¾", btn: "à¤¸à¤¤à¥à¤¯à¤¾à¤ªà¤¿à¤¤ à¤•à¤°à¥‡à¤‚" },
        role: { title: "à¤‡à¤¸à¤•à¤¾ à¤‰à¤ªà¤¯à¥‹à¤— à¤•à¥Œà¤¨ à¤•à¤° à¤°à¤¹à¤¾ à¤¹à¥ˆ?", sub: "à¤¹à¤® à¤†à¤ªà¤•à¥‡ à¤²à¤¿à¤ à¤…à¤¨à¥à¤­à¤µ à¤•à¥‹ à¤…à¤¨à¥à¤•à¥‚à¤²à¤¿à¤¤ à¤•à¤°à¥‡à¤‚à¤—à¥‡à¥¤", self_title: "à¤®à¥‡à¤°à¥‡ à¤²à¤¿à¤ à¤¸à¥‡à¤Ÿ à¤…à¤ª à¤•à¤°à¥‡à¤‚", self_desc: "à¤®à¥ˆà¤‚ à¤à¤• à¤¸à¥à¤µà¤¸à¥à¤¥ à¤¦à¤¿à¤¨à¤šà¤°à¥à¤¯à¤¾ à¤¬à¤¨à¤¾à¤ à¤°à¤–à¤¨à¤¾ à¤šà¤¾à¤¹à¤¤à¤¾ à¤¹à¥‚à¤à¥¤", loved_title: "à¤ªà¥à¤°à¤¿à¤¯à¤œà¤¨ à¤•à¥‡ à¤²à¤¿à¤ à¤¸à¥‡à¤Ÿ à¤…à¤ª à¤•à¤°à¥‡à¤‚", loved_desc: "à¤®à¥ˆà¤‚ à¤ªà¤°à¤¿à¤µà¤¾à¤° à¤•à¥‡ à¤¸à¤¦à¤¸à¥à¤¯ à¤•à¥€ à¤¦à¥‡à¤–à¤­à¤¾à¤² à¤ªà¥à¤°à¤¬à¤‚à¤§à¤¿à¤¤ à¤•à¤° à¤°à¤¹à¤¾ à¤¹à¥‚à¤à¥¤" },
        home: { greeting: "à¤¨à¤®à¤¸à¥à¤¤à¥‡", btn1: "à¤–à¥‡à¤² à¤–à¥‡à¤²à¥‡à¤‚", btn2: "à¤ªà¤°à¤¿à¤µà¤¾à¤°", btn3: "à¤¦à¤¿à¤¨à¤šà¤°à¥à¤¯à¤¾", btn4: "à¤†à¤ªà¤¾à¤¤à¤•à¤¾à¤²à¥€à¤¨" }
    },
    "mni": { 
        label: "Manipuri (ê¯ƒê¯¤ê¯‡ê¯©ê¯‚ê¯£ê¯Ÿ)",
        changeLang: "ê¯‚ê¯£ê¯Ÿ ê¯ê¯£ê¯¡ê¯—ê¯£ê¯›ê¯Ž",
        landing: { greeting: "ê¯ˆê¯¨ê¯”ê¯¨ê¯ê¯–ê¯”ê¯¤", next: "ê¯ƒê¯Šê¯ª" },
        login: { title: "ê¯ˆê¯¨ê¯”ê¯¨ê¯ê¯–ê¯”ê¯¤", sub: "ê¯ƒê¯ˆê¯¥ ê¯†ê¯ ê¯Šê¯…ê¯•ê¯¥ ê¯‘ê¯€ê¯¨ê¯žê¯„ê¯¥ ê¯ƒê¯”ê¯£ê¯œ ê¯ê¯¥ê¯žê¯†ê¯¤ê¯Ÿê¯•ê¯¤ê¯Œê¯¨", phone: "ê¯ê¯£ê¯Ÿ ê¯…ê¯ê¯•ê¯” (ê¯ƒê¯Šê¯§ ê¯‡ê¯¥ê¯•ê¯¥)*", email: "ê¯ê¯ƒê¯¦ê¯œ (ê¯‘ê¯„ê¯¥ê¯ê¯•)", btn: "OTP ê¯Šê¯¥ê¯•ê¯¤ê¯Œê¯¨" },
        otp: { title: "ê¯ê¯£ê¯Ÿ ê¯Œê¯¦ê¯¡ê¯ê¯¤ê¯Ÿê¯•ê¯¤ê¯Œê¯¨", sub: "ê¯…ê¯ê¯¥ê¯›ê¯€ê¯¤ ê¯…ê¯ê¯•ê¯”ê¯—ê¯¥ OTP ê¯Šê¯¥ê¯ˆê¯­ê¯”ê¯¦", btn: "ê¯Œê¯¦ê¯¡ê¯ê¯¤ê¯Ÿê¯•ê¯¤ê¯Œê¯¨" },
        role: { title: "ê¯ƒê¯ê¯¤ ê¯€ê¯…ê¯¥ê¯…ê¯¥ ê¯ê¯¤ê¯–ê¯¤ê¯Ÿê¯…ê¯”ê¯¤ê¯•ê¯…ê¯£?", sub: "ê¯‘ê¯©ê¯ˆê¯£ê¯Œê¯…ê¯¥ ê¯…ê¯ê¯¥ê¯›ê¯€ê¯¤ê¯—ê¯ƒê¯› ê¯‘ê¯¦ê¯›ê¯ê¯„ê¯¤ê¯”ê¯¤ê¯Œê¯¦ê¯Ÿê¯ ê¯‘ê¯—ê¯¨ ê¯ê¯¦ê¯ê¯’ê¯…ê¯¤ê¯«", self_title: "ê¯ê¯ê¯¥ê¯’ê¯¤ê¯—ê¯ƒê¯› ê¯ê¯¦ê¯  ê¯‘ê¯ž ê¯‡ê¯§ê¯•ê¯¤ê¯Œê¯¨", self_desc: "ê¯‘ê¯©ê¯…ê¯¥ ê¯ê¯›ê¯†ê¯¥ê¯¡ ê¯ê¯•ê¯¥ ê¯”ê¯¨ê¯‡ê¯¤ê¯Ÿ ê¯‘ê¯ƒê¯¥ ê¯Šê¯ê¯…ê¯¤ê¯¡ê¯ê¯«", loved_title: "ê¯…ê¯¨ê¯¡ê¯ê¯¤ê¯”ê¯•ê¯¥ ê¯ƒê¯¤ê¯‘ê¯£ê¯ ê¯‘ê¯ƒê¯’ê¯¤ê¯—ê¯ƒê¯› ê¯ê¯¦ê¯  ê¯‘ê¯ž ê¯‡ê¯§ê¯•ê¯¤ê¯Œê¯¨", loved_desc: "ê¯‘ê¯©ê¯…ê¯¥ ê¯ê¯ƒê¯¨ê¯¡ê¯’ê¯¤ ê¯ƒê¯¤ê¯‘ê¯£ê¯ ê¯‘ê¯ƒê¯’ê¯¤ ê¯Œê¯¦ê¯¡ê¯ê¯¤ê¯Ÿê¯•ê¯’ê¯¤ ê¯Šê¯•ê¯› ê¯‡ê¯§ê¯”ê¯¤ê¯«" },
        home: { greeting: "ê¯ˆê¯¨ê¯”ê¯¨ê¯ê¯–ê¯”ê¯¤", btn1: "ê¯ê¯¥ê¯Ÿê¯…ê¯•", btn2: "ê¯ê¯ƒê¯¨ê¯¡", btn3: "ê¯Šê¯§ê¯”ê¯", btn4: "ê¯†ê¯¦ê¯›ê¯ê¯¤ê¯Ÿ" }
    }
    // Note: Other languages omitted in this snippet for brevity but should follow same structure
};

let currentLang = 'en';

function changeLanguage(langCode, btnElement = null) {
    currentLang = langCode;
    const data = langData[langCode] || langData['en'];
    
    if (langCode === 'mni') {
        document.body.classList.add('font-manipuri');
    } else {
        document.body.classList.remove('font-manipuri');
    }
    
    // Landing
    if(document.getElementById('greeting-text')) document.getElementById('greeting-text').innerText = data.landing.greeting;
    if(document.getElementById('next-btn-text')) document.getElementById('next-btn-text').innerText = data.landing.next;
    
    // Login
    if(document.getElementById('login-title')) document.getElementById('login-title').innerText = data.login.title;
    if(document.getElementById('login-subtitle')) document.getElementById('login-subtitle').innerText = data.login.sub;
    if(document.getElementById('label-phone')) document.getElementById('label-phone').innerText = data.login.phone;
    if(document.getElementById('label-email')) document.getElementById('label-email').innerText = data.login.email;
    if(document.getElementById('btn-send-otp')) document.getElementById('btn-send-otp').innerText = data.login.btn;

    // OTP
    if(document.getElementById('otp-title')) document.getElementById('otp-title').innerText = data.otp.title;
    if(document.getElementById('otp-subtitle')) document.getElementById('otp-subtitle').innerText = data.otp.sub;
    if(document.getElementById('btn-verify-otp')) document.getElementById('btn-verify-otp').innerText = data.otp.btn;

    // Role
    if(document.getElementById('role-title')) document.getElementById('role-title').innerText = data.role.title;
    if(document.getElementById('role-subtitle')) document.getElementById('role-subtitle').innerText = data.role.sub;
    if(document.getElementById('role-self-title')) document.getElementById('role-self-title').innerText = data.role.self_title;
    if(document.getElementById('role-self-desc')) document.getElementById('role-self-desc').innerText = data.role.self_desc;
    if(document.getElementById('role-loved-title')) document.getElementById('role-loved-title').innerText = data.role.loved_title;
    if(document.getElementById('role-loved-desc')) document.getElementById('role-loved-desc').innerText = data.role.loved_desc;

    // Home
    if(document.getElementById('home-greeting')) document.getElementById('home-greeting').innerText = data.home.greeting;
    if(document.getElementById('btn-game')) document.getElementById('btn-game').innerText = data.home.btn1;
    if(document.getElementById('btn-family')) document.getElementById('btn-family').innerText = data.home.btn2;
    if(document.getElementById('btn-routine')) document.getElementById('btn-routine').innerText = data.home.btn3;
    if(document.getElementById('btn-sos')) document.getElementById('btn-sos').innerText = data.home.btn4;
    
    if(document.getElementById('change-lang-text')) document.getElementById('change-lang-text').innerText = data.changeLang;
    
    if (btnElement) {
        document.querySelectorAll('.lang-card').forEach(card => card.classList.remove('active-lang'));
        btnElement.classList.add('active-lang');
    }
}

// --- Navigation Flow ---

function goToLogin() {
    localStorage.setItem('appLang', currentLang);
    showScreen('login-screen');
}

let currentAuthPhone = '';

async function sendOTP() {
    const phoneInput = document.getElementById('phone-input');
    const phone = phoneInput ? phoneInput.value.replace(/\D/g, '').slice(-10) : '';
    if (!phone || phone.length < 10) {
        alert("Please enter a valid 10-digit Indian phone number.");
        return;
    }
    currentAuthPhone = phone;

    const btn = document.getElementById('btn-send-otp');
    const originalText = btn.innerText;
    btn.innerText = "Sending SMS...";
    btn.disabled = true;

    try {
        const res = await fetch('/api/send-otp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone })
        });
        const data = await res.json();

        if (data.success) {
            showScreen('otp-screen');
            const subTitle = document.getElementById('otp-subtitle');
            if (subTitle) {
                subTitle.innerText = "OTP sent to +91 " + phone;
            }

            // Clear inputs & focus
            ['otp1', 'otp2', 'otp3', 'otp4'].forEach((id, idx) => {
                const el = idx === 0 ? document.querySelector('.otp-group .otp-input:first-child') : document.getElementById(id);
                if (el) el.value = '';
            });
            const firstInput = document.querySelector('.otp-group .otp-input:first-child');
            if (firstInput) firstInput.focus();

            if (data.delivered) {
                console.log("[Fast2SMS] Real SMS dispatched via Fast2SMS (0.20 INR). Check your phone!");
            } else if (data.fallback_otp) {
                // If website verification is still pending on Fast2SMS dashboard, alert user nicely
                alert("Fast2SMS Notice: " + data.gateway_error + "\n\nFor this test, your verification OTP is: " + data.fallback_otp);
            }
        } else {
            alert(data.message || "Failed to send OTP. Please try again.");
        }
    } catch (err) {
        console.warn("Backend not running or offline, using fallback:", err);
        // Direct UI transition fallback
        showScreen('otp-screen');
    } finally {
        btn.innerText = originalText;
        btn.disabled = false;
    }
}

function moveToNext(current, nextFieldID) {
    if (current.value.length >= 1 && nextFieldID) {
        document.getElementById(nextFieldID).focus();
    }
}

async function verifyOTP() {
    const inputs = document.querySelectorAll('.otp-group .otp-input');
    let enteredOTP = '';
    inputs.forEach(input => enteredOTP += input.value.trim());

    if (enteredOTP.length < 4) {
        alert("Please enter the complete 4-digit OTP.");
        return;
    }

    const btn = document.getElementById('btn-verify-otp');
    const originalText = btn.innerHTML;
    btn.innerText = "Verifying...";
    btn.disabled = true;

    try {
        const res = await fetch('/api/verify-otp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: currentAuthPhone, otp: enteredOTP })
        });
        const data = await res.json();

        if (data.success) {
            localStorage.setItem('isAuthenticated', 'true');
            showScreen('role-screen');
        } else {
            alert(data.message || "Invalid OTP. Please check the code and try again.");
            inputs.forEach(input => input.value = '');
            if (inputs[0]) inputs[0].focus();
        }
    } catch (err) {
        console.warn("Verify endpoint offline, allowing demo:", err);
        localStorage.setItem('isAuthenticated', 'true');
        showScreen('role-screen');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

function selectRole(role) {
    localStorage.setItem('userRole', role);
    
    if(role === 'self') {
        // Patient uses it themselves -> Run the invisible assessment
        showScreen('welcome-screen');
    } else {
        // Caregiver is setting it up -> Open the deep Profile Builder (starts at Clinical)
        localStorage.setItem('hasCompletedAssessment', 'true');
        showScreen('screen-clinical');
    }
}


// Universal Reset Function
function resetLanguage() {
    localStorage.clear(); // Clear all memory to test flow again
    location.reload(); 
}

function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.style.display = 'none');
    
    if (screenId === 'game-menu-screen') {
        if(typeof renderGamesList === 'function') renderGamesList();
        document.getElementById(screenId).style.display = 'block';
    } else if (screenId === 'home-screen') {
        if(typeof updateProgressUI === 'function') updateProgressUI();
        document.getElementById(screenId).style.display = 'block';
    } else if (screenId === 'family-screen') {
        if(typeof renderFamilyMenu === 'function') renderFamilyMenu();
        document.getElementById(screenId).style.display = 'block';
    } else if (screenId === 'routine-screen') {
        if(typeof initRoutineScreen === 'function') initRoutineScreen();
        document.getElementById(screenId).style.display = 'block';
    } else {
        const el = document.getElementById(screenId);
        if(el) el.style.display = 'flex';
    }

    const nav = document.querySelector('.bottom-nav');
    if (nav) {
        if (['home-screen', 'progress-screen', 'routine-screen'].includes(screenId)) {
            nav.style.display = 'flex';
        } else {
            nav.style.display = 'none';
        }
    }

    if (screenId === 'progress-screen') {
        if(typeof renderProgressTab === 'function') renderProgressTab();
    }
}

window.onload = () => {
    const savedLang = localStorage.getItem('appLang');
    const isAuth = localStorage.getItem('isAuthenticated');
    const hasRole = localStorage.getItem('userRole');
    const hasAssessed = localStorage.getItem('hasCompletedAssessment');

    if (savedLang) {
        changeLanguage(savedLang);
        
        // Strict Flow Routing based on offline state
        if(isAuth && hasRole) {
            if (hasRole === 'self' && !hasAssessed) {
                // Intercept them if they closed app before finishing assessment
                showScreen('welcome-screen');
            } else {
                showScreen('home-screen');
            }
        } else if (isAuth) {
            showScreen('role-screen');
        } else {
            showScreen('login-screen');
        }
    } else {
        // Default to English Landing Page
        changeLanguage('en');
    }
};

// --- Side Drawer Functions ---
function toggleDrawer() {
    const overlay = document.getElementById('drawer-overlay');
    const drawer = document.getElementById('side-drawer');
    if (overlay && drawer) {
        overlay.classList.toggle('active');
        drawer.classList.toggle('open');
    }
}

function openProfileSection(sectionId) {
    toggleDrawer(); // close drawer
    showScreen('screen-' + sectionId);
}






// ==========================================
// MODULE 2: GAUNTLET COGNITIVE ASSESSMENT
// Lead: Member 2 (Core Cognitive Engine)
// Contains 13 Randomized Cognitive Games mapped to Dementia Types
// ==========================================

var gauntletInterval = null;
var gauntletTimeLeft = 300;
var currentPhase = 0;
window.savedRecallItems = [];
window.gauntletTasksQueue = [];

function startAssessment() {
    showScreen('assessment-screen');
    gauntletTimeLeft = 300;
    currentPhase = 0;
    window.savedRecallItems = [];
    
    // Shuffle 13 games
    window.gauntletTasksQueue = [0,1,2,3,4,5,6,7,8,9,10,11,12].sort(() => Math.random() - 0.5);
    let recallIdx = window.gauntletTasksQueue.indexOf(11);
    if (recallIdx < 5) {
        let swap = window.gauntletTasksQueue[12];
        window.gauntletTasksQueue[12] = 11;
        window.gauntletTasksQueue[recallIdx] = swap;
    }

    document.getElementById('gauntlet-timer').innerText = '05:00';
    document.getElementById('gauntlet-progress').style.width = '0%';
    
    const area = document.getElementById('gauntlet-area');
    if(!document.getElementById('demo-skip')) {
        const skipBtn = document.createElement('button');
        skipBtn.id = 'demo-skip';
        skipBtn.innerText = 'Skip to Results (Demo Mode)';
        skipBtn.style.position = 'absolute'; skipBtn.style.bottom = '10px'; skipBtn.style.background = 'transparent';
        skipBtn.style.border = 'none'; skipBtn.style.textDecoration = 'underline'; skipBtn.style.color = '#999';
        skipBtn.onclick = finishAssessment;
        document.getElementById('assessment-screen').appendChild(skipBtn);
    }
    
    clearInterval(gauntletInterval);
    gauntletInterval = setInterval(() => {
        gauntletTimeLeft--;
        let m = Math.floor(gauntletTimeLeft / 60).toString().padStart(2, '0');
        let s = (gauntletTimeLeft % 60).toString().padStart(2, '0');
        document.getElementById('gauntlet-timer').innerText = m + ':' + s;
        
        let pct = ((300 - gauntletTimeLeft) / 300) * 100;
        document.getElementById('gauntlet-progress').style.width = pct + '%';

        if (gauntletTimeLeft <= 0) {
            clearInterval(gauntletInterval);
            finishAssessment();
        }
    }, 1000);

    loadNextGauntletTask();
}

function loadNextGauntletTask() {
    if (gauntletTimeLeft <= 0) return;
    const area = document.getElementById('gauntlet-area');
    area.innerHTML = ''; 
    
    if (window.gauntletTasksQueue.length === 0) {
        finishAssessment();
        return;
    }

    let taskType = window.gauntletTasksQueue.shift();
    currentPhase++; 

    let level = 1; let levelText = 'Level 1: Easy';
    if (currentPhase > 4 && currentPhase <= 9) {
        level = 2; levelText = 'Level 2: Medium';
    } else if (currentPhase > 9) {
        level = 3; levelText = 'Level 3: Hard';
    }
    
    const badge = document.createElement('div');
    badge.innerText = levelText;
    badge.style.padding = '4px 8px'; 
    badge.style.background = level === 1 ? '#4CAF50' : level === 2 ? '#FF9800' : '#F44336';
    badge.style.color = 'white'; badge.style.borderRadius = '8px'; badge.style.fontSize = '14px'; badge.style.fontWeight = 'bold';
    badge.style.marginBottom = '15px';
    badge.style.display = 'inline-block';
    area.appendChild(badge);

    const titleEl = document.getElementById('gauntlet-title');

    const emj = {
        fruits: ['&#x1F34E;','&#x1F34C;','&#x1F347;','&#x1F353;','&#x1F34A;'],
        shapes: ['&#x1F534;','&#x1F7E2;','&#x1F7E1;','&#x1F535;','&#x1F7E3;'],
        animals: ['&#x1F436;','&#x1F431;','&#x1F42D;','&#x1F430;','&#x1F43B;'],
        weather: ['&#x2600;&#xFE0F;','&#x1F327;&#xFE0F;','&#x26C4;','&#x1F308;','&#x26A1;']
    };

    function makeGrid(items, onSelect) {
        const grid = document.createElement('div');
        grid.style.display = 'grid'; 
        grid.style.gridTemplateColumns = items.length <= 4 ? 'repeat(2, 1fr)' : 'repeat(3, 1fr)'; 
        grid.style.gap = '15px'; 
        grid.style.marginTop = '20px';
        grid.style.width = '100%';
        grid.style.maxWidth = '400px';
        items.forEach(obj => {
            const btn = document.createElement('button'); btn.innerHTML = obj; 
            btn.style.padding = '15px'; btn.style.fontSize = '35px'; 
            btn.style.borderRadius = '12px'; btn.style.border = '2px solid #ccc'; 
            btn.style.background = 'white'; btn.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
            btn.style.cursor = 'pointer';
            btn.onclick = () => onSelect(obj, btn);
            grid.appendChild(btn);
        });
        area.appendChild(grid);
    }
    
    function makeInst(text) {
        const inst = document.createElement('p'); inst.innerHTML = text; inst.style.fontSize = '20px'; inst.style.fontWeight = '600'; inst.style.color = '#37474F'; inst.style.textAlign = 'center'; area.appendChild(inst);
    }

    if (taskType === 0) {
        titleEl.innerText = 'Game 1: Sequence Memory (AD/LBD)';
        let seqLen = level === 1 ? 3 : 4; // user requested max 4 items for level 3
        let speed = level === 1 ? 2000 : level === 2 ? 1600 : 1300;
        let pool = emj.shapes;
        let seq = [];
        for(let i=0; i<seqLen; i++) seq.push(pool[Math.floor(Math.random()*pool.length)]);
        window.savedRecallItems.push(seq[0]); 
        
        makeInst('Watch the sequence...');
        const disp = document.createElement('h2'); disp.style.fontSize = '80px'; disp.style.margin = '30px 0'; area.appendChild(disp);
        
        let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            if(step < seqLen) {
                disp.innerHTML = seq[step];
                setTimeout(() => { disp.innerHTML = ''; }, speed - 300);
                step++;
            } else {
                clearInterval(intv);
                area.innerHTML = ''; area.appendChild(badge); makeInst('Tap the sequence in order:');
                let userSeq = [];
                makeGrid(pool, (val, btn) => {
                    userSeq.push(val);
                    btn.style.background = '#E0F2F1';
                    if(userSeq.length === seqLen) setTimeout(loadNextGauntletTask, 300);
                });
            }
        }, speed);
    }
    else if (taskType === 1) {
        titleEl.innerText = 'Game 2: Grid Memory (AD)';
        let count = level === 1 ? 3 : 4; // user requested max 4
        makeInst('Remember the green squares');
        
        const grid = document.createElement('div');
        grid.style.display = 'grid'; grid.style.gridTemplateColumns = 'repeat(3, 1fr)'; grid.style.gap = '15px'; grid.style.margin = '30px auto'; grid.style.width = '240px'; grid.style.height = '240px';
        let cells = [];
        let active = [];
        for(let i=0; i<9; i++) {
            let c = document.createElement('div'); c.style.background = '#eee'; c.style.borderRadius = '12px'; c.style.boxShadow = 'inset 0 0 5px rgba(0,0,0,0.1)';
            grid.appendChild(c); cells.push(c);
        }
        area.appendChild(grid);
        
        while(active.length < count) {
            let r = Math.floor(Math.random()*9);
            if(!active.includes(r)) active.push(r);
        }
        
        active.forEach(idx => cells[idx].style.background = '#00796B');
        
        setTimeout(() => {
            if(gauntletTimeLeft <= 0) return;
            cells.forEach(c => c.style.background = '#eee');
            makeInst('Tap the squares that were green');
            let found = 0;
            cells.forEach((c, idx) => {
                c.onclick = () => {
                    if(active.includes(idx)) { c.style.background = '#4CAF50'; found++; }
                    else { c.style.background = '#F44336'; }
                    if(found === count) setTimeout(loadNextGauntletTask, 500);
                }
            });
        }, level === 1 ? 4000 : level === 2 ? 3000 : 2500);
    }
    else if (taskType === 2) {
        titleEl.innerText = 'Game 3: Target Detection (FTD/VCI)';
        makeInst('Tap the Blue Circle (&#x1F535;) as soon as it appears!');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '40px 0'; box.style.fontSize = '80px'; area.appendChild(box);
        let reps = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let isTarget = Math.random() < 0.3 || reps === 3;
            box.innerHTML = isTarget ? '&#x1F535;' : '&#x1F7E2;';
            box.onclick = () => {
                if(isTarget) { clearInterval(intv); box.style.background = '#E8F5E9'; box.style.borderRadius = '50%'; setTimeout(loadNextGauntletTask, 500); }
            };
            reps++;
            if (reps > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 1500 : level === 2 ? 1200 : 1000);
        }, level === 1 ? 2500 : level === 2 ? 2000 : 1500);
    }
    else if (taskType === 3) {
        titleEl.innerText = 'Game 4: Attention Switching (FTD)';
        makeInst(level === 1 ? 'If EVEN tap Left, If ODD tap Right' : 'If RED tap Left, If BLUE tap Right');
        
        let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; area.appendChild(target);
        let val = level === 1 ? Math.floor(Math.random()*8)+2 : (Math.random() > 0.5 ? '&#x1F534;' : '&#x1F535;');
        target.innerHTML = val;
        
        const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
        let btnL = document.createElement('button'); btnL.innerText = 'LEFT'; btnL.style.padding = '25px'; btnL.style.fontSize = '24px'; btnL.style.flex = '1'; btnL.style.borderRadius = '16px'; btnL.style.border = '2px solid #ccc'; btnL.onclick = loadNextGauntletTask;
        let btnR = document.createElement('button'); btnR.innerText = 'RIGHT'; btnR.style.padding = '25px'; btnR.style.fontSize = '24px'; btnR.style.flex = '1'; btnR.style.borderRadius = '16px'; btnR.style.border = '2px solid #ccc'; btnR.onclick = loadNextGauntletTask;
        flex.appendChild(btnL); flex.appendChild(btnR); area.appendChild(flex);
    }
    else if (taskType === 4) {
        titleEl.innerText = 'Game 5: Quick Match (LBD/PD)';
        makeInst('Find the matching animal:');
        
        const targetDisp = document.createElement('div');
        targetDisp.innerHTML = '&#x1F431;'; // Cat
        targetDisp.style.fontSize = '60px';
        targetDisp.style.margin = '10px 0';
        area.appendChild(targetDisp);

        let count = level === 1 ? 4 : level === 2 ? 6 : 9;
        let pool = emj.animals.slice();
        let items = ['&#x1F431;'];
        while(items.length < count) {
            items.push(pool[Math.floor(Math.random()*pool.length)]);
        }
        items.sort(() => Math.random() - 0.5);
        makeGrid(items, (val) => {
            if(val === '&#x1F431;') loadNextGauntletTask();
        });
    }
    else if (taskType === 5) {
        titleEl.innerText = 'Game 6: Pattern Completion (AD/VCI)';
        makeInst('What number comes next?');
        let pat = level === 1 ? [2, 4, 6, 8] : level === 2 ? [5, 10, 15, 20] : [1, 2, 4, 8];
        let ans = level === 1 ? 10 : level === 2 ? 25 : 16;
        let pText = document.createElement('h2'); pText.innerText = pat.join(', ') + ', ?'; pText.style.margin = '30px 0'; pText.style.letterSpacing = '2px'; pText.style.color = '#00796B'; area.appendChild(pText);
        
        let opts = [ans, ans+1, ans-1, ans+2].sort(() => Math.random()-0.5);
        makeGrid(opts, (val) => { loadNextGauntletTask(); });
    }
    else if (taskType === 6) {
        titleEl.innerText = 'Game 7: Matrix Reasoning (AD)';
        makeInst('Complete the logic:');
        let pText = document.createElement('h2'); pText.innerHTML = '&#x2600;&#xFE0F; -> &#x1F305; <br><br> &#x1F319; -> ?'; pText.style.margin = '30px 0'; pText.style.fontSize = '40px'; area.appendChild(pText);
        
        let opts = ['&#x1F30C;', '&#x1F327;&#xFE0F;', '&#x26C4;', '&#x1F308;'].sort(() => Math.random()-0.5);
        makeGrid(opts, (val) => { loadNextGauntletTask(); });
    }
    else if (taskType === 7) {
        titleEl.innerText = 'Game 8: N-Back Memory (FTD/VCI)';
        makeInst('Tap Match if the current shape is EXACTLY the same as the PREVIOUS shape.');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '20px 0'; box.style.fontSize = '80px'; area.appendChild(box);
        
        let btn = document.createElement('button'); btn.innerText = 'MATCH!'; btn.style.padding = '20px'; btn.style.width = '100%'; btn.style.maxWidth = '300px'; btn.style.fontSize = '24px'; btn.style.fontWeight = 'bold'; btn.style.borderRadius = '16px'; btn.style.border = '2px solid #ccc'; btn.style.background = 'white'; area.appendChild(btn);
        
        let pool = emj.shapes;
        let last = '';
        let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let cur = Math.random() < 0.4 && last !== '' ? last : pool[Math.floor(Math.random()*pool.length)];
            box.innerHTML = cur;
            btn.onclick = () => { if(cur === last) { clearInterval(intv); btn.style.background = '#C8E6C9'; setTimeout(loadNextGauntletTask, 500); } };
            last = cur;
            step++;
            if(step > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 2000 : 1500);
        }, level === 1 ? 3500 : 2500);
    }
    else if (taskType === 8) {
        titleEl.innerText = 'Game 9: Go/No-Go (FTD/PD)';
        makeInst('Tap GREEN (&#x1F7E2;). DO NOT tap RED (&#x1F534;).');
        const box = document.createElement('div'); box.style.height = '120px'; box.style.margin = '40px 0'; box.style.fontSize = '100px'; box.style.cursor = 'pointer'; area.appendChild(box);
        let taps = 0; let step = 0;
        let intv = setInterval(() => {
            if(gauntletTimeLeft <= 0) { clearInterval(intv); return; }
            let isGreen = Math.random() > 0.4;
            box.innerHTML = isGreen ? '&#x1F7E2;' : '&#x1F534;';
            box.onclick = () => { if(isGreen) taps++; };
            step++;
            if(taps >= 3 || step > 6) { clearInterval(intv); loadNextGauntletTask(); }
            setTimeout(() => { box.innerHTML = ''; }, level === 1 ? 1500 : level === 2 ? 1200 : 1000);
        }, level === 1 ? 2500 : 1800);
    }
    else if (taskType === 9) {
        titleEl.innerText = 'Game 10: Rule Learning (FTD/PD)';
        let isReversed = level > 1;
        makeInst(isReversed ? 'Reverse Rule: Apple Right, Banana Left' : 'Rule: Apple Left, Banana Right');
        
        let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; area.appendChild(target);
        let val = Math.random() > 0.5 ? '&#x1F34E;' : '&#x1F34C;';
        target.innerHTML = val;
        
        const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
        let btnL = document.createElement('button'); btnL.innerText = 'LEFT'; btnL.style.padding = '25px'; btnL.style.fontSize = '24px'; btnL.style.flex = '1'; btnL.style.borderRadius = '16px'; btnL.style.border = '2px solid #ccc'; btnL.onclick = loadNextGauntletTask;
        let btnR = document.createElement('button'); btnR.innerText = 'RIGHT'; btnR.style.padding = '25px'; btnR.style.fontSize = '24px'; btnR.style.flex = '1'; btnR.style.borderRadius = '16px'; btnR.style.border = '2px solid #ccc'; btnR.onclick = loadNextGauntletTask;
        flex.appendChild(btnL); flex.appendChild(btnR); area.appendChild(flex);
    }
    else if (taskType === 10) {
        titleEl.innerText = 'Game 11: Memory Recognition (AD)';
        
        makeInst('Memorize these symbols...');
        const tempPool = ['&#x1F30E;', '&#x1F680;', '&#x1F3B2;', '&#x1F514;'];
        const disp = document.createElement('div');
        disp.innerHTML = tempPool.join(' &nbsp; ');
        disp.style.fontSize = '40px'; disp.style.margin = '30px 0';
        area.appendChild(disp);
        
        setTimeout(() => {
            if(gauntletTimeLeft <= 0) return;
            area.innerHTML = ''; area.appendChild(badge);
            makeInst('Did you just see this symbol?');
            let isOld = Math.random() > 0.5;
            let val = isOld ? tempPool[Math.floor(Math.random()*tempPool.length)] : '&#x1F381;';
            
            let target = document.createElement('h2'); target.style.fontSize = '100px'; target.style.margin = '30px 0'; target.innerHTML = val; area.appendChild(target);
            
            const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center'; flex.style.width = '100%'; flex.style.maxWidth = '400px';
            let btnO = document.createElement('button'); btnO.innerText = 'YES'; btnO.style.padding = '25px'; btnO.style.fontSize = '24px'; btnO.style.flex = '1'; btnO.style.borderRadius = '16px'; btnO.style.border = '2px solid #4CAF50'; btnO.onclick = loadNextGauntletTask;
            let btnN = document.createElement('button'); btnN.innerText = 'NO'; btnN.style.padding = '25px'; btnN.style.fontSize = '24px'; btnN.style.flex = '1'; btnN.style.borderRadius = '16px'; btnN.style.border = '2px solid #F44336'; btnN.onclick = loadNextGauntletTask;
            flex.appendChild(btnO); flex.appendChild(btnN); area.appendChild(flex);
        }, 3000);
    }
    else if (taskType === 11) {
        titleEl.innerText = 'Game 12: Delayed Recall (AD/MCI)';
        makeInst('Which shape was the very FIRST one you saw at the start?');
        let opts = emj.shapes.slice().sort(() => Math.random() - 0.5);
        makeGrid(opts, (val, btn) => { 
            btn.style.background = '#C8E6C9';
            setTimeout(loadNextGauntletTask, 500); 
        });
    }
    else if (taskType === 12) {
        titleEl.innerText = 'Game 13: Order Planning (VCI/PD)';
        makeInst('Tap the numbers from Smallest to Largest');
        let arr = [12, 45, 7, 89];
        if (level === 2) arr = [3, -5, 12, 0, 8];
        if (level === 3) arr = [105, 42, 99, 13, 76];
        let sorted = arr.slice().sort((a,b) => a-b);
        let currentIdx = 0;
        
        let shuffled = arr.slice().sort(() => Math.random() - 0.5);
        makeGrid(shuffled, (val, btn) => {
            if(val == sorted[currentIdx]) {
                btn.style.background = '#4CAF50'; btn.style.color = 'white';
                currentIdx++;
                if(currentIdx === arr.length) setTimeout(loadNextGauntletTask, 500);
            } else {
                btn.style.background = '#F44336'; btn.style.color = 'white';
            }
        });
    }
}


function finishAssessment() {
    clearInterval(gauntletInterval);
    
    if (window.isSingleGame) {
        window.isSingleGame = false;
        document.getElementById('gauntlet-timer').style.display = 'inline-block';
        document.getElementById('gauntlet-progress').parentElement.style.display = 'block';
        if (typeof window.routineTaskCallback === 'function') {
            let cb = window.routineTaskCallback;
            window.routineTaskCallback = null;
            cb();
            return;
        }
        showScreen('game-menu-screen');
        return;
    }
    
    document.getElementById('gauntlet-title').innerText = 'Complete!';
    
    // Assign mock scores for the demo to show priority sorting
    let mockScores = {};
    for(let i=0; i<13; i++) {
        mockScores[i] = Math.floor(Math.random() * 60) + 40; // 40-100
    }
    // Force a couple of "Must Play" and "Recommended"
    mockScores[0] = 30; // Sequence Memory
    mockScores[4] = 60; // Quick Match
    mockScores[8] = 25; // Go/No-Go
    localStorage.setItem('gameScores', JSON.stringify(mockScores));
    
    const skipBtn = document.getElementById('demo-skip');

    if(skipBtn) skipBtn.remove();
    
    const matrix = [
        { c: "Mild Cognitive Impairment", ui: "Standard", games: ["Memory Match", "Pattern Match", "Daily Routine"] },
        { c: "Alzheimer's Disease", ui: "Anchor Mode", games: ["Face-Name Match", "Daily Routine", "Reminiscence"] },
        { c: "Vascular Dementia", ui: "Focus Mode", games: ["Dual Task", "Market Math", "Selective Attention"] },
        { c: "Lewy Body Dementia", ui: "High Contrast Mode", games: ["Clock Activity", "Object Recognition", "Shape Sorting"] },
        { c: "Frontotemporal Dementia", ui: "Calm Mode", games: ["Categorization", "Family Quiz", "Word Association"] },
        { c: "Primary Progressive Aphasia", ui: "Voice Mode", games: ["Name the Object", "Picture Description", "Music Memory"] },
        { c: "Parkinson's Dementia", ui: "Steady Mode", games: ["Target Tap", "Spatial Arrangement", "Pack the Bag"] },
        { c: "Sundowner Syndrome", ui: "Night Mode", games: ["Music Memory", "Day/Time Orientation", "Evening Calm"] },
        { c: "The Wanderer", ui: "Safety Mode", games: ["What Comes Next", "Spatial Arrangement", "Wayfinding"] },
        { c: "Sensory Processing", ui: "Therapy Mode", games: ["Listen & Answer", "Personal Memory", "Audio Trivia"] }
    ];
    
    const profile = matrix[Math.floor(Math.random() * matrix.length)];
    localStorage.setItem('diagnosis', JSON.stringify(profile));
    
    setTimeout(() => {
        showScreen('analyzing-screen');
        const textEl = document.getElementById('analyzing-text');
        if (textEl) textEl.innerText = 'Detecting cognitive signature...';
        
        setTimeout(() => {
            if (textEl) textEl.innerText = 'Applying ' + profile.ui + '...';
        }, 1500);
        
        setTimeout(() => {
            localStorage.setItem('hasCompletedAssessment', 'true');
            applyMatrixToHome(profile);
            showScreen('home-screen');
        }, 3000);
    }, 500);
}

function applyMatrixToHome(profile) {
    const home = document.getElementById('home-screen');
    const header = home.querySelector('.app-header');
    
    home.style.background = '#FDFCF0';
    home.style.color = '#37474F';
    header.style.background = 'linear-gradient(135deg, #00796B, #004D40)';
    header.style.borderBottom = 'none';
    
    if (profile.ui === 'High Contrast Mode') {
        home.style.background = '#000000';
        document.querySelectorAll('.quest-text h2').forEach(h => h.style.color = '#FFEB3B');
        document.querySelectorAll('.quest-text p').forEach(p => p.style.color = '#FFF');
        header.style.background = '#000';
        header.style.borderBottom = '4px solid #FFEB3B';
    } else if (profile.ui === 'Night Mode') {
        home.style.background = '#1a1a2e';
        header.style.background = '#16213e';
        document.querySelectorAll('.quest-text h2').forEach(h => h.style.color = '#FFF');
    } else if (profile.ui === 'Calm Mode') {
        home.style.background = '#E8F5E9';
        header.style.background = '#A5D6A7';
    } else if (profile.ui === 'Steady Mode') {
        document.querySelectorAll('.quest-card').forEach(c => c.style.padding = '30px');
    }
    
    const quests = home.querySelectorAll('.quest-card');
    if(quests.length >= 3) {
        quests[0].querySelector('h2').innerText = profile.games[0]; quests[0].querySelector('p').innerText = 'Targeted Exercise';
        quests[0].onclick = () => openQuestGame(profile.games[0]);
        quests[1].querySelector('h2').innerText = profile.games[1]; quests[1].querySelector('p').innerText = 'Targeted Exercise';
        quests[1].onclick = () => openQuestGame(profile.games[1]);
        quests[2].querySelector('h2').innerText = profile.games[2]; quests[2].querySelector('p').innerText = 'Targeted Exercise';
        quests[2].onclick = () => openQuestGame(profile.games[2]);
        
        document.getElementById('home-greeting').innerText = 'Your Care Plan';
        const subtitle = header.querySelector('p');
        subtitle.innerText = 'Active: ' + profile.ui;
        subtitle.style.fontWeight = 'bold';
        subtitle.style.color = '#FFC107';
    }
}


function finishFamilyQuiz(btn) {
    btn.style.background = '#4CAF50';
    btn.style.color = 'white';
    setTimeout(() => {
        if (window.pendingRoutineTask) {
            verifyPendingGame();
        } else {
            showScreen('home-screen');
        }
        btn.style.background = 'white';
        btn.style.color = '#37474F';
    }, 1000);
}

// --- DYNAMIC QUEST ENGINE (Playable Games) ---
function openQuestGame(gameName) {
    if (gameName === 'Family Quiz') {
        showScreen('ai-screen');
        return;
    }
    showScreen('game-screen');
    const area = document.getElementById('game-area');
    if(!area) return;
    area.innerHTML = ''; 

    // Header
    const header = document.createElement('div');
    header.style.display = 'flex'; header.style.justifyContent = 'space-between'; header.style.alignItems = 'center'; header.style.marginBottom = '30px';
    const backBtn = document.createElement('button');
    backBtn.innerHTML = '<span class="material-symbols-rounded" style="vertical-align: middle; margin-right: 4px;">arrow_back</span> Back';
    backBtn.style.background = 'transparent'; backBtn.style.border = 'none'; backBtn.style.fontSize = '18px'; backBtn.style.color = '#37474F';
    backBtn.onclick = () => {
        if (window.pendingRoutineTask) {
            window.pendingRoutineTask = null; // Clear pending without credit
            showScreen('routine-screen');
        } else {
            showScreen('home-screen');
        }
    };
    const title = document.createElement('h2');
    title.innerText = gameName; title.style.margin = '0'; title.style.color = '#00796B';
    header.appendChild(backBtn); header.appendChild(title);
    area.appendChild(header);

    // Dynamic Game Content Generator
    const gameBoard = document.createElement('div');
    gameBoard.style.textAlign = 'center';

    // 1. Memory / Matching Games
    if (gameName.includes('Match') || gameName.includes('Recognition') || gameName.includes('Quiz') || gameName === 'Reminiscence') {
        const p = document.createElement('p'); p.innerText = gameName === 'Face-Name Match' ? 'Match the family member to their name' : 'Tap the matching pairs'; p.style.marginBottom = '20px';
        gameBoard.appendChild(p);
        const grid = document.createElement('div');
        grid.style.display = 'grid'; grid.style.gridTemplateColumns = '1fr 1fr'; grid.style.gap = '15px';
        
        let icons = ['Apple', 'Apple', 'Boat', 'Boat', 'Cat', 'Cat'];
if(gameName === 'Face-Name Match') icons = ['John (Photo)', 'John', 'Mary (Photo)', 'Mary', 'Lily (Photo)', 'Lily'];
        
        icons.sort(() => 0.5 - Math.random()).forEach(icon => {
            const card = document.createElement('div');
            card.innerText = '?'; card.style.fontSize = '40px'; card.style.padding = '30px 0'; card.style.background = '#00796B'; card.style.color = 'white'; card.style.borderRadius = '12px'; card.style.cursor = 'pointer';
            card.onclick = () => { card.innerText = icon; card.style.background = '#FF8A65'; };
            grid.appendChild(card);
        });
        gameBoard.appendChild(grid);
    } 
    // 2. Logic / Math / Prediction Games
    else if (gameName.includes('Logic') || gameName.includes('Math') || gameName.includes('Sorting') || gameName.includes('Next') || gameName.includes('Trivia')) {
        const p = document.createElement('p'); p.innerText = 'Solve the sequence'; p.style.marginBottom = '20px';
        gameBoard.appendChild(p);
        
        const eq = document.createElement('h1'); 
        eq.innerText = gameName.includes('Math') ? '2 + 3 + 1 = ?' : 'ðŸ”µ âž¡ï¸ ðŸ”´ âž¡ï¸ ðŸ”µ âž¡ï¸ ?'; 
        eq.style.fontSize = '40px'; eq.style.marginBottom = '30px';
        gameBoard.appendChild(eq);
        
        const flex = document.createElement('div'); flex.style.display = 'flex'; flex.style.gap = '20px'; flex.style.justifyContent = 'center';
        
        let answers = gameName.includes('Math') ? ['5', '6', '7'] : ['Yes', 'No'];
        
        answers.forEach(ans => {
            const btn = document.createElement('button'); btn.innerText = ans; btn.style.padding = '20px 40px'; btn.style.fontSize = '24px'; btn.style.borderRadius = '12px'; btn.style.border = '2px solid #00796B'; btn.style.background = 'white';
            btn.onclick = () => btn.style.background = '#4CAF50';
            flex.appendChild(btn);
        });
        gameBoard.appendChild(flex);
    }
    // 3. Audio / Speech Games
    else if (gameName.includes('Audio') || gameName.includes('Listen') || gameName.includes('Music') || gameName.includes('Word') || gameName.includes('Description') || gameName.includes('Object')) {
        const p = document.createElement('p'); p.innerText = 'Listen and respond...'; p.style.marginBottom = '20px';
        gameBoard.appendChild(p);
        const icon = document.createElement('div'); icon.innerText = '♪'; icon.style.fontSize = '80px'; icon.style.marginBottom = '30px';
        gameBoard.appendChild(icon);
        const btn = document.createElement('button'); btn.innerText = 'Tap to Speak / Play'; btn.style.padding = '15px 30px'; btn.style.fontSize = '18px'; btn.style.borderRadius = '20px'; btn.style.background = '#FF8A65'; btn.style.color = 'white'; btn.style.border = 'none';
        gameBoard.appendChild(btn);
    }
    // 4. Drawing / Motor Games
    else if (gameName.includes('Clock Activity') || gameName.includes('Target Tap') || gameName.includes('Dual Task')) {
        const p = document.createElement('p'); p.innerText = gameName.includes('Clock') ? 'Draw the hands for 3:15' : 'Tap the targets quickly'; p.style.marginBottom = '20px';
        gameBoard.appendChild(p);
        const circle = document.createElement('div');
        circle.style.width = '200px'; circle.style.height = '200px'; circle.style.borderRadius = '50%'; circle.style.border = '4px solid #00796B'; circle.style.margin = '0 auto 30px'; circle.style.position = 'relative';
        gameBoard.appendChild(circle);
    }
    // 5. Interactive Categorization Game
    else {
        const p = document.createElement('p'); p.innerText = 'Tap an item, then tap the correct category bin:'; p.style.marginBottom = '20px'; p.style.color = '#666';
        gameBoard.appendChild(p);
        
        let selectedItem = null;
        
        // Items to categorize
        const items = [
            { id: 1, name: '🍎 Apple', cat: 'Fruit' },
            { id: 2, name: '🐶 Dog', cat: 'Animal' },
            { id: 3, name: '🍌 Banana', cat: 'Fruit' },
            { id: 4, name: '🐱 Cat', cat: 'Animal' }
        ];
        
        const itemContainer = document.createElement('div');
        itemContainer.style.display = 'flex'; itemContainer.style.gap = '10px'; itemContainer.style.justifyContent = 'center'; itemContainer.style.marginBottom = '30px'; itemContainer.style.flexWrap = 'wrap';
        
        const binsContainer = document.createElement('div');
        binsContainer.style.display = 'flex'; binsContainer.style.gap = '20px'; binsContainer.style.justifyContent = 'space-around';
        
        const drawItems = () => {
            itemContainer.innerHTML = '';
            items.filter(i => !i.sorted).forEach(item => {
                const btn = document.createElement('button');
                btn.innerText = item.name;
                btn.style.padding = '10px 15px'; btn.style.fontSize = '18px'; btn.style.borderRadius = '12px'; btn.style.border = '2px solid #00796B'; btn.style.background = selectedItem === item.id ? '#00796B' : '#E0F2F1'; btn.style.color = selectedItem === item.id ? 'white' : '#00796B'; btn.style.cursor = 'pointer'; btn.style.fontWeight = 'bold'; btn.style.transition = '0.2s';
                btn.onclick = () => {
                    selectedItem = item.id;
                    drawItems();
                };
                itemContainer.appendChild(btn);
            });
            if(items.filter(i => !i.sorted).length === 0) {
                itemContainer.innerHTML = '<div style="color: #4CAF50; font-weight: bold; font-size: 18px;">All sorted! ✔</div>';
            }
        };
        
        ['Fruit', 'Animal'].forEach(cat => {
            const bin = document.createElement('div');
            bin.style.flex = '1'; bin.style.padding = '20px'; bin.style.border = '3px dashed #FF8A65'; bin.style.borderRadius = '16px'; bin.style.background = '#FFF3E0'; bin.style.cursor = 'pointer'; bin.style.minHeight = '150px';
            bin.innerHTML = '<h3 style="margin:0 0 10px; color:#E64A19;">' + cat + '</h3><div class="bin-content" style="font-size: 24px; display: flex; flex-wrap: wrap; gap: 5px; justify-content: center;"></div>';
            bin.onclick = () => {
                if(selectedItem !== null) {
                    const item = items.find(i => i.id === selectedItem);
                    if(item.cat === cat) {
                        item.sorted = true;
                        selectedItem = null;
                        bin.querySelector('.bin-content').innerHTML += '<span>' + item.name.split(' ')[0] + '</span>'; // Just the emoji
                        drawItems();
                    } else {
                        bin.style.borderColor = 'red';
                        setTimeout(() => bin.style.borderColor = '#FF8A65', 300);
                    }
                }
            };
            binsContainer.appendChild(bin);
        });
        
        drawItems();
        gameBoard.appendChild(itemContainer);
        gameBoard.appendChild(binsContainer);
    }

    const finishBtn = document.createElement('button');
    finishBtn.innerText = 'Submit & Finish';
    finishBtn.style.background = '#FF8A65'; finishBtn.style.color = 'white'; finishBtn.style.border = 'none'; finishBtn.style.padding = '16px 30px'; finishBtn.style.fontSize = '18px'; finishBtn.style.borderRadius = '20px'; finishBtn.style.marginTop = '40px'; finishBtn.style.cursor = 'pointer'; finishBtn.style.width = '100%';
    finishBtn.onclick = () => {
        if (window.pendingRoutineTask) {
            verifyPendingGame();
        } else {
            showScreen('home-screen');
        }
    };
    gameBoard.appendChild(finishBtn);

    area.appendChild(gameBoard);
}

// --- ROUTINE & NAV LOGIC ---
function switchNav(screenId) {
    if(!localStorage.getItem('hasCompletedAssessment') || localStorage.getItem('hasCompletedAssessment') !== 'true') return;
    
    // Only switch if trying to go to valid tabs
    if(screenId !== 'home-screen' && screenId !== 'routine-screen' && screenId !== 'progress-screen') return;
    
    showScreen(screenId);
    
    document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
    if(screenId === 'home-screen') {
        const n = document.getElementById('nav-home');
        if(n) n.classList.add('active');
    }
    if(screenId === 'routine-screen') {
        const n = document.getElementById('nav-routine');
        if(n) n.classList.add('active');
    }
    if(screenId === 'progress-screen') {
        const n = document.getElementById('nav-progress');
        if(n) n.classList.add('active');
    }
}

let completedTasks = 0;
window.pendingRoutineTask = null;

function completeRoutineTask(el, type, gameIndex) {
    if(el.classList.contains('done')) return;
    
    if(type === 'game') {
        window.pendingRoutineTask = el; // Store it but DON'T check it off yet!
        let storedProfile = localStorage.getItem('diagnosis');
        let targetGame = 'Memory Match';
        if(storedProfile) {
            let p = JSON.parse(storedProfile);
            if(p.games && p.games[gameIndex]) targetGame = p.games[gameIndex];
        }
        openQuestGame(targetGame);
        
    } else if (type === 'walk') {
        window.pendingRoutineTask = el;
        showScreen('walk-screen');
    } else if (type === 'water') {
        // Just instantly check it off (ethical honor system as user requested)
        el.classList.add('done');
        completedTasks++;
        const progText = document.getElementById('routine-progress-text');
        if(progText) progText.innerText = completedTasks + ' / 5 Completed';
        
        stats.hyd = 1;
        renderProgressTab();
    }
}

function verifyPendingGame() {
    if (window.pendingRoutineTask && !window.pendingRoutineTask.classList.contains('done')) {
        window.pendingRoutineTask.classList.add('done');
        completedTasks++;
        const progText = document.getElementById('routine-progress-text');
        if(progText) progText.innerText = completedTasks + ' / 5 Completed';
        
        // Update Stats
        const taskText = window.pendingRoutineTask.innerText.toLowerCase();
        if(taskText.includes('walk') || taskText.includes('mobility')) {
            stats.phy = 1;
        } else {
            stats.cog = Math.min(3, stats.cog + 1);
        }
        renderProgressTab();
        
        window.pendingRoutineTask = null;
    }
    showScreen('routine-screen');
}


// --- WALK TRACKER LOGIC ---
let walkInterval = null;
let walkTime = 0;
let walkSteps = 0;
let walkActive = false;

function toggleWalk() {
    const btn = document.getElementById('btn-walk-action');
    const icon = document.getElementById('icon-walk-action');
    const text = document.getElementById('text-walk-action');
    const ring = document.getElementById('walk-ring');

    if (walkActive) {
        // Pause
        pauseWalk();
        btn.style.background = '#4CAF50';
        icon.innerText = 'play_arrow';
        text.innerText = 'Resume Walk';
    } else {
        // Start
        walkActive = true;
        btn.style.background = '#F44336';
        icon.innerText = 'pause';
        text.innerText = 'Pause';
        
        walkInterval = setInterval(() => {
            walkTime += 1; // 1 second = 1 minute in demo
            walkSteps += Math.floor(Math.random() * 120) + 80; // Fake steps
            
            document.getElementById('walk-steps').innerText = walkSteps;
            let m = Math.floor(walkTime);
            document.getElementById('walk-time').innerText = (m < 10 ? '0' + m : m) + ':00';
            
            const progress = Math.min(1, walkTime / 10); // 10 seconds/minutes goal
            ring.style.transform = `rotate(${-45 + (progress * 360)}deg)`;
            
            if (walkTime >= 10) {
                finishWalk();
            }
        }, 1000);
    }
}

function pauseWalk() {
    walkActive = false;
    clearInterval(walkInterval);
}

function finishWalk() {
    pauseWalk();
    // Show overlay
    const overlay = document.getElementById('walk-confetti');
    overlay.style.display = 'flex';
    
    setTimeout(() => {
        overlay.style.display = 'none';
        walkTime = 0;
        walkSteps = 0;
        document.getElementById('walk-steps').innerText = '0';
        document.getElementById('walk-time').innerText = '00:00';
        document.getElementById('walk-ring').style.transform = 'rotate(-45deg)';
        
        const btn = document.getElementById('btn-walk-action');
        btn.style.background = '#4CAF50';
        document.getElementById('icon-walk-action').innerText = 'play_arrow';
        document.getElementById('text-walk-action').innerText = 'Start Walk';
        
        verifyPendingGame(); // Checks it off and adds to progress
    }, 3000); // 3 seconds congratulations
}

// ====================================================
// MODULE 4: ACCURATE REAL-TIME PROGRESS & ANALYTICS ENGINE
// ====================================================

function getAccurateProgressMetrics() {
    const routine = typeof getRoutineData === 'function' ? getRoutineData() : {
        morning_brain: false,
        hydration: false,
        water_count: 0,
        walk: false,
        afternoon_puzzle: false,
        evening_audio: false
    };

    // 1. Routine Tasks (5 total)
    let routineCompleted = 0;
    if (routine.morning_brain) routineCompleted++;
    if (routine.hydration) routineCompleted++;
    if (routine.walk) routineCompleted++;
    if (routine.afternoon_puzzle) routineCompleted++;
    if (routine.evening_audio) routineCompleted++;

    // 2. Hydration: Goal is 6 glasses
    const waterGoal = 6;
    const waterCompleted = Math.min(waterGoal, routine.water_count || 0);

    // 3. Mobility: Goal is 1 walk session (10 mins)
    const walkGoal = 1;
    const walkCompleted = routine.walk ? 1 : 0;

    // 4. Cognitive Domains:
    let scores = {};
    try {
        scores = JSON.parse(localStorage.getItem('gameScores')) || {};
    } catch(e) { scores = {}; }

    // Family Therapy quiz count
    const familyPlayed = (typeof familyQuizCount !== 'undefined' && familyQuizCount > 0) ? Math.min(4, familyQuizCount) : 0;

    // Cognitive Domain Breakdown:
    // Memory: Morning brain + Sequence(0), Grid(1), N-Back(7), Old/New(10), Recall(11)
    const memTasksTotal = 3;
    let memTasksDone = 0;
    if (routine.morning_brain) memTasksDone++;
    if (scores[0] !== undefined || scores[1] !== undefined) memTasksDone++;
    if (scores[10] !== undefined || scores[11] !== undefined) memTasksDone++;
    memTasksDone = Math.min(memTasksTotal, memTasksDone);

    // Attention & Speed: Target(2), Switch(3), Go/No-Go(8)
    const attTasksTotal = 2;
    let attTasksDone = 0;
    if (scores[2] !== undefined || scores[3] !== undefined) attTasksDone++;
    if (scores[8] !== undefined) attTasksDone++;
    attTasksDone = Math.min(attTasksTotal, attTasksDone);

    // Reasoning & Logic: Match(4), Pattern(5), Matrix(6), Rule(9), Order(12)
    const reasTasksTotal = 2;
    let reasTasksDone = 0;
    if (routine.afternoon_puzzle || scores[4] !== undefined) reasTasksDone++;
    if (scores[5] !== undefined || scores[6] !== undefined || scores[12] !== undefined) reasTasksDone++;
    reasTasksDone = Math.min(reasTasksTotal, reasTasksDone);

    // Family & Social Reminiscence:
    const famTasksTotal = 2;
    let famTasksDone = 0;
    if (familyPlayed >= 1) famTasksDone++;
    if (familyPlayed >= 3) famTasksDone++;

    // Audio Therapy & Relaxation:
    const audioTasksTotal = 1;
    const audioTasksDone = routine.evening_audio ? 1 : 0;

    // Overall Adherence Percentage (Accurately computed from 5 daily routine tasks):
    const overallPct = Math.min(100, Math.round((routineCompleted / 5) * 100));

    return {
        routineCompleted,
        routineTotal: 5,
        waterCompleted,
        waterGoal,
        walkCompleted,
        walkGoal,
        overallPct,
        cognitive: {
            "Memory & Recall": { done: memTasksDone, total: memTasksTotal },
            "Attention & Reflexes": { done: attTasksDone, total: attTasksTotal },
            "Reasoning & Executive Logic": { done: reasTasksDone, total: reasTasksTotal },
            "Family & Face Recognition": { done: famTasksDone, total: famTasksTotal },
            "Calming Audio & Breathing": { done: audioTasksDone, total: audioTasksTotal }
        }
    };
}

function updateProgressUI() {
    const metrics = getAccurateProgressMetrics();

    // 1. Home Screen Progress Widget
    const homeFill = document.getElementById('home-progress-fill');
    const homePct = document.getElementById('home-progress-pct');
    if (homeFill) {
        homeFill.style.width = `${metrics.overallPct}%`;
        homeFill.style.background = metrics.overallPct >= 80 ? '#4CAF50' : (metrics.overallPct >= 40 ? '#FFC107' : '#FF8A65');
    }
    if (homePct) {
        homePct.innerText = `${metrics.overallPct}% (${metrics.routineCompleted} / ${metrics.routineTotal} Tasks)`;
    }

    // 2. Routine Screen Progress Widget
    const rBar = document.getElementById('routine-progress-bar');
    const rText = document.getElementById('routine-progress-text');
    if (rBar) rBar.style.width = `${metrics.overallPct}%`;
    if (rText) rText.innerText = `${metrics.routineCompleted} / ${metrics.routineTotal} Completed`;
}

function renderProgressTab() {
    const metrics = getAccurateProgressMetrics();
    updateProgressUI();

    const overallPct = metrics.overallPct;

    let themeColor = '';
    if (overallPct < 40) {
        themeColor = '#FF8A65';
    } else if (overallPct <= 70) {
        themeColor = '#FFC107';
    } else {
        themeColor = '#4CAF50';
    }

    // 1. Hero Circular Ring
    const ring = document.getElementById('overall-ring');
    if (ring) {
        const radius = ring.r.baseVal.value || 70;
        const circumference = radius * 2 * Math.PI;
        ring.style.strokeDasharray = `${circumference} ${circumference}`;
        const offset = circumference - (overallPct / 100) * circumference;
        ring.style.strokeDashoffset = offset;
        ring.style.stroke = themeColor;
        ring.style.transition = 'stroke-dashoffset 0.6s ease-out, stroke 0.4s ease';
    }

    const pctText = document.getElementById('overall-percentage');
    if (pctText) {
        pctText.innerText = `${overallPct}%`;
        pctText.style.color = themeColor;
    }

    // 2. Physical & Routine Cards
    const hydText = document.getElementById('hyd-text');
    const hydBar = document.getElementById('hyd-bar');
    if (hydText) hydText.innerText = `${metrics.waterCompleted} / ${metrics.waterGoal} Glasses`;
    if (hydBar) {
        const hydPct = (metrics.waterCompleted / metrics.waterGoal) * 100;
        hydBar.style.width = `${hydPct}%`;
        hydBar.style.background = '#0288D1';
        hydBar.style.transition = 'width 0.5s ease-out';
    }

    const mobText = document.getElementById('mob-text');
    const mobBar = document.getElementById('mob-bar');
    if (mobText) mobText.innerText = `${metrics.walkCompleted} / ${metrics.walkGoal} Session`;
    if (mobBar) {
        const mobPct = (metrics.walkCompleted / metrics.walkGoal) * 100;
        mobBar.style.width = `${mobPct}%`;
        mobBar.style.background = '#FF9800';
        mobBar.style.transition = 'width 0.5s ease-out';
    }

    // 3. Cognitive Domain Breakdown
    const cogContainer = document.getElementById('cognitive-progress-list');
    if (cogContainer) {
        cogContainer.innerHTML = '';
        for (let cat in metrics.cognitive) {
            const item = metrics.cognitive[cat];
            const pct = item.total === 0 ? 0 : Math.round((item.done / item.total) * 100);
            const card = document.createElement('div');
            card.className = 'progress-card';
            card.style.background = 'white';
            card.style.borderRadius = '14px';
            card.style.padding = '14px 16px';
            card.style.marginBottom = '12px';
            card.style.boxShadow = '0 2px 6px rgba(0,0,0,0.05)';
            card.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                    <span style="font-weight: 700; font-size: 14px; color: #37474F;">${cat}</span>
                    <span style="font-size: 13px; font-weight: 700; color: ${pct >= 100 ? '#4CAF50' : '#00796B'};">${item.done} / ${item.total}</span>
                </div>
                <div class="bar-bg" style="width: 100%; height: 8px; background: #eee; border-radius: 4px; overflow: hidden;">
                    <div style="width: ${pct}%; height: 100%; background: ${pct >= 100 ? '#4CAF50' : (pct >= 50 ? '#00796B' : '#FF9800')}; border-radius: 4px; transition: 0.5s ease-out;"></div>
                </div>
            `;
            cogContainer.appendChild(card);
        }
    }
}

// --- Games Menu Logic ---
const GAME_NAMES = [
    { id: 0, name: "Sequence Memory", desc: "Remember the order of shapes", icon: "&#x1F534;" },
    { id: 1, name: "Grid Memory", desc: "Recall the green squares", icon: "&#x1F7E9;" },
    { id: 2, name: "Target Detection", desc: "Tap the blue circle quickly", icon: "&#x1F535;" },
    { id: 3, name: "Attention Switching", desc: "Follow changing rules", icon: "&#x2194;&#xFE0F;" },
    { id: 4, name: "Quick Match", desc: "Find the matching animal", icon: "&#x1F431;" },
    { id: 5, name: "Pattern Completion", desc: "Find the missing number", icon: "&#x1F522;" },
    { id: 6, name: "Matrix Reasoning", desc: "Complete the visual logic", icon: "&#x1F9E9;" },
    { id: 7, name: "N-Back Memory", desc: "Match current with previous", icon: "&#x23EA;" },
    { id: 8, name: "Go/No-Go", desc: "Inhibit incorrect responses", icon: "&#x1F6A6;" },
    { id: 9, name: "Rule Learning", desc: "Learn and reverse rules", icon: "&#x1F4D6;" },
    { id: 10, name: "Memory Recognition", desc: "Identify symbols you saw", icon: "&#x1F441;&#xFE0F;" },
    { id: 11, name: "Delayed Recall", desc: "Remember the first shape", icon: "&#x23F3;" },
    { id: 12, name: "Order Planning", desc: "Sort numbers in order", icon: "&#x1F4CA;" }
];

function renderGamesList() {
    const container = document.getElementById('games-list-container');
    if (!container) return;
    container.innerHTML = '';
    
    let scores = JSON.parse(localStorage.getItem('gameScores')) || {};
    
    let sortedGames = GAME_NAMES.slice().sort((a, b) => {
        let scoreA = scores[a.id] !== undefined ? scores[a.id] : 100;
        let scoreB = scores[b.id] !== undefined ? scores[b.id] : 100;
        return scoreA - scoreB;
    });

    sortedGames.forEach(game => {
        let score = scores[game.id];
        let tag = '';
        if (score !== undefined) {
            if (score <= 40) tag = '<span style="background: #F44336; color: white; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; margin-left: 10px; display: inline-block;">Must Play</span>';
            else if (score <= 70) tag = '<span style="background: #FF9800; color: white; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; margin-left: 10px; display: inline-block;">Recommended</span>';
            else tag = '<span style="background: #4CAF50; color: white; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; margin-left: 10px; display: inline-block;">Good</span>';
        }

        const card = document.createElement('div');
        card.className = 'card';
        card.style.display = 'flex';
        card.style.alignItems = 'center';
        card.style.padding = '15px';
        card.style.cursor = 'pointer';
        card.style.marginBottom = '10px';
        card.onclick = () => startSingleGame(game.id);
        
        card.innerHTML = `
            <div class="icon-box" style="background: #E0F2F1; color: #00796B; font-size: 24px; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; border-radius: 12px;">
                ${game.icon}
            </div>
            <div style="flex: 1; margin-left: 15px; text-align: left;">
                <h3 style="color: #37474F; font-size: 16px; margin: 0 0 4px 0; display: flex; align-items: center;">${game.name} ${tag}</h3>
                <p style="color: #78909C; font-size: 13px; margin: 0;">${game.desc}</p>
            </div>
            <span style="color: #B0BEC5;">&#x25B6;</span>
        `;
        container.appendChild(card);
    });
}

window.isSingleGame = false;
function startSingleGame(taskType) {
    showScreen('assessment-screen');
    window.savedRecallItems = ['&#x1F7E2;']; // Mock for memory game
    gauntletTimeLeft = 9999;
    document.getElementById('gauntlet-timer').style.display = 'none';
    document.getElementById('gauntlet-progress').parentElement.style.display = 'none';
    
    window.gauntletTasksQueue = [taskType];
    window.isSingleGame = true;
    currentPhase = 8; // Force medium/hard level randomly for standalone
    loadNextGauntletTask();
}

function quitAssessment() {
    window.isQuitting = true;
    if (typeof gauntletInterval !== 'undefined') clearInterval(gauntletInterval);
    gauntletTimeLeft = 0; // Signals local game intervals to terminate
    
    // Clear the active game area to prevent rogue clicks
    const area = document.getElementById('gauntlet-area');
    if(area) area.innerHTML = '';
    
    setTimeout(() => {
        if (window.isSingleGame) {
            window.isSingleGame = false;
            // Restore UI elements for next full assessment
            document.getElementById('gauntlet-timer').style.display = 'inline-block';
            document.getElementById('gauntlet-progress').parentElement.style.display = 'block';
            if (typeof window.routineTaskCallback === 'function') {
                window.routineTaskCallback = null;
                showScreen('routine-screen');
                return;
            }
            showScreen('game-menu-screen');
        } else {
            showScreen('home-screen');
        }
        window.isQuitting = false;
    }, 150);
}

// --- Family Targeted Therapy Module ---
const familyMembers = [
    { id: 1, name: "Kalyani (Grandmother)", relation: "Mother / Grandmother", image: "face_1.jpg", zoom: "54% 43%", desc: "Sitting center in purple sweater" },
    { id: 2, name: "Ramesh (Grandfather)", relation: "Father / Grandfather", image: "face_2.jpg", zoom: "49% 22%", desc: "Standing top-center in gold tie" },
    { id: 3, name: "Rahul (Son)", relation: "Son", image: "face_3.jpg", zoom: "42% 35%", desc: "Standing mid-left in black suit" },
    { id: 4, name: "Priya (Daughter-in-law)", relation: "Daughter-in-law", image: "face_4.jpg", zoom: "28% 42%", desc: "Sitting left in cream dress" },
    { id: 5, name: "Sunita (Daughter)", relation: "Daughter", image: "face_5.jpg", zoom: "73% 40%", desc: "Sitting right in dark navy dress" },
    { id: 6, name: "Amit (Elder Son)", relation: "Elder Son", image: "face_6.jpg", zoom: "70% 21%", desc: "Standing top-right in glasses" },
    { id: 7, name: "Kavita (Elder Daughter-in-law)", relation: "Elder Daughter-in-law", image: "face_7.jpg", zoom: "31% 26%", desc: "Standing top-left in white cardigan" }
];

function renderFamilyMenu() {
    const area = document.getElementById('family-game-area');
    if(!area) return;
    area.innerHTML = `
        <div style="background: white; border-radius: 16px; padding: 20px; width: 100%; max-width: 420px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); text-align: center;">
            <div style="width: 100%; height: 210px; border-radius: 12px; overflow: hidden; margin-bottom: 15px; border: 3px solid #FF8A65; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                <img src="family_group.jpg" style="width: 100%; height: 100%; object-fit: cover; object-position: center;">
            </div>
            <h3 style="color: #37474F; margin-bottom: 8px; font-size: 22px;">Family Memory Album</h3>
            <p style="color: #78909C; margin-bottom: 20px; font-size: 14px;">Look at your family picture. Test your memory by identifying each family member!</p>
            <button onclick="startFamilyQuiz()" style="background: #FF8A65; color: white; border: none; padding: 15px 30px; font-size: 20px; border-radius: 30px; font-weight: bold; cursor: pointer; width: 100%; box-shadow: 0 4px 6px rgba(255, 138, 101, 0.3);">Start Recognition Game</button>
        </div>
    `;
}

function startFamilyQuiz() {
    const area = document.getElementById('family-game-area');
    
    // Random target
    let target = familyMembers[Math.floor(Math.random() * familyMembers.length)];
    
    // 1 correct + 2 random choices
    let others = familyMembers.filter(m => m.id !== target.id).sort(() => Math.random() - 0.5);
    let options = [target, others[0], others[1]].sort(() => Math.random() - 0.5);
    
    let html = `
        <div style="display: flex; flex-direction: column; align-items: center; width: 100%; max-width: 400px;">
            <!-- Group view with Zoom/Crop Focus -->
            <div style="position: relative; width: 190px; height: 190px; border-radius: 50%; overflow: hidden; border: 5px solid #FF8A65; box-shadow: 0 6px 15px rgba(0,0,0,0.15); margin-bottom: 12px; background: #fff;">
                <img src="${target.image}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
            
            <div style="background: #FFF3E0; border: 1px solid #FFE0B2; border-radius: 12px; padding: 6px 16px; margin-bottom: 20px;">
                <span style="color: #E65100; font-size: 13px; font-weight: 600;">&#x1F50D; Clue: ${target.desc}</span>
            </div>

            <h2 style="color: #37474F; font-size: 24px; margin: 0 0 20px 0; font-weight: 700;">Who is this person in the family?</h2>
            
            <div style="display: flex; flex-direction: column; gap: 14px; width: 100%;">
    `;
    
    options.forEach(opt => {
        html += `<button class="family-opt-btn" onclick="checkFamilyAnswer(${opt.id}, ${target.id}, this)" style="background: white; border: 2px solid #ddd; padding: 18px 20px; font-size: 19px; border-radius: 14px; color: #37474F; font-weight: bold; cursor: pointer; text-align: left; position: relative; box-shadow: 0 2px 5px rgba(0,0,0,0.05); transition: 0.2s;">
            <span style="display: block; font-size: 13px; color: #FF8A65; font-weight: 600; text-transform: uppercase; margin-bottom: 4px;">${opt.relation}</span>
            ${opt.name}
        </button>`;
    });
    
    html += `
            </div>
            
            <button onclick="renderFamilyMenu()" style="margin-top: 25px; background: none; border: none; color: #90A4AE; font-size: 14px; cursor: pointer; text-decoration: underline;">
                &#x21A9; Back to Family Album
            </button>
        </div>
    `;
    area.innerHTML = html;
}

let familyQuizScore = 0;
let familyQuizCount = 0;

function checkFamilyAnswer(selectedId, targetId, btnEl) {
    const allBtns = document.querySelectorAll('.family-opt-btn');
    allBtns.forEach(b => b.disabled = true);
    
    const targetObj = familyMembers.find(m => m.id === targetId);

    if (selectedId === targetId) {
        familyQuizScore++;
        familyQuizCount++;
        btnEl.style.background = '#E8F5E9';
        btnEl.style.borderColor = '#4CAF50';
        btnEl.innerHTML += '<span style="position: absolute; right: 20px; top: 50%; transform: translateY(-50%); font-size: 26px;">&#x2705;</span>';
        
        // Show celebratory popup
        showFamilyCongratsPopup(targetObj, true);
    } else {
        familyQuizCount++;
        btnEl.style.background = '#FFEBEE';
        btnEl.style.borderColor = '#F44336';
        btnEl.innerHTML += '<span style="position: absolute; right: 20px; top: 50%; transform: translateY(-50%); font-size: 26px;">&#x274C;</span>';
        
        showFamilyCongratsPopup(targetObj, false);
    }
}

function showFamilyCongratsPopup(member, isCorrect) {
    // Remove existing modal if any
    const existing = document.getElementById('family-congrats-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'family-congrats-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100vw';
    modal.style.height = '100vh';
    modal.style.background = 'rgba(0, 0, 0, 0.65)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '9999';
    modal.style.animation = 'fadeIn 0.25s ease-out';

    const card = document.createElement('div');
    card.style.background = 'white';
    card.style.borderRadius = '24px';
    card.style.padding = '30px 24px';
    card.style.width = '90%';
    card.style.maxWidth = '360px';
    card.style.textAlign = 'center';
    card.style.boxShadow = '0 20px 40px rgba(0,0,0,0.3)';
    card.style.transform = 'scale(0.9)';
    card.style.transition = '0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)';

    if (isCorrect) {
        card.innerHTML = `
            <div style="font-size: 60px; line-height: 1; margin-bottom: 12px; animation: bounce 0.6s ease;">&#x1F389;</div>
            <h2 style="color: #2E7D32; font-size: 26px; margin: 0 0 6px 0; font-weight: 800;">Wonderful!</h2>
            <p style="color: #666; font-size: 15px; margin: 0 0 18px 0;">You remembered correctly!</p>
            
            <div style="position: relative; width: 120px; height: 120px; margin: 0 auto 16px; border-radius: 50%; overflow: hidden; border: 4px solid #4CAF50; box-shadow: 0 6px 14px rgba(76, 175, 80, 0.3);">
                <img src="${member.image}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>

            <h3 style="color: #37474F; font-size: 20px; margin: 0 0 4px 0;">${member.name}</h3>
            <p style="color: #FF8A65; font-weight: 700; font-size: 14px; text-transform: uppercase; margin: 0 0 20px 0;">${member.relation}</p>
            
            <button id="next-family-btn" style="background: linear-gradient(135deg, #4CAF50, #2E7D32); color: white; border: none; padding: 14px 28px; font-size: 17px; font-weight: 700; border-radius: 30px; cursor: pointer; width: 100%; box-shadow: 0 4px 12px rgba(46, 125, 50, 0.35);">
                Next Family Member &#x27A1;
            </button>
        `;
    } else {
        card.innerHTML = `
            <div style="font-size: 55px; line-height: 1; margin-bottom: 12px;">&#x1F49B;</div>
            <h2 style="color: #E65100; font-size: 24px; margin: 0 0 6px 0; font-weight: 800;">Good Try!</h2>
            <p style="color: #666; font-size: 14px; margin: 0 0 16px 0;">Here is a gentle reminder:</p>
            
            <div style="position: relative; width: 110px; height: 110px; margin: 0 auto 14px; border-radius: 50%; overflow: hidden; border: 4px solid #FF9800; box-shadow: 0 6px 14px rgba(255, 152, 0, 0.3);">
                <img src="${member.image}" style="width: 100%; height: 100%; object-fit: cover;">
            </div>

            <h3 style="color: #37474F; font-size: 19px; margin: 0 0 4px 0;">${member.name}</h3>
            <p style="color: #E65100; font-weight: 700; font-size: 14px; text-transform: uppercase; margin: 0 0 18px 0;">${member.relation}</p>
            
            <button id="next-family-btn" style="background: linear-gradient(135deg, #FF9800, #F57C00); color: white; border: none; padding: 14px 28px; font-size: 17px; font-weight: 700; border-radius: 30px; cursor: pointer; width: 100%; box-shadow: 0 4px 12px rgba(245, 124, 0, 0.35);">
                Try Next &#x27A1;
            </button>
        `;
    }

    modal.appendChild(card);
    document.body.appendChild(modal);

    // Animate pop-in
    setTimeout(() => { card.style.transform = 'scale(1)'; }, 20);

    document.getElementById('next-family-btn').onclick = () => {
        modal.remove();
        startFamilyQuiz();
    };
}

// ====================================================
// MODULE 3: DAILY WELLNESS ROUTINE & AUDIO THERAPY
// ====================================================

const DEFAULT_ROUTINE = {
    morning_brain: false,
    hydration: false,
    water_count: 0,
    walk: false,
    afternoon_puzzle: false,
    evening_audio: false,
    date: new Date().toDateString()
};

function getRoutineData() {
    let saved = localStorage.getItem('neosaarthi_routine_v2');
    if (!saved) return { ...DEFAULT_ROUTINE };
    try {
        let parsed = JSON.parse(saved);
        // Reset if new calendar day (ethical, realistic daily routine)
        if (parsed.date !== new Date().toDateString()) {
            return { ...DEFAULT_ROUTINE, date: new Date().toDateString() };
        }
        return parsed;
    } catch(e) {
        return { ...DEFAULT_ROUTINE };
    }
}

function saveRoutineData(data) {
    localStorage.setItem('neosaarthi_routine_v2', JSON.stringify(data));
}

function initRoutineScreen() {
    const data = getRoutineData();
    const taskMap = {
        'morning_brain': 'routine-task-morning',
        'hydration': 'routine-task-water',
        'walk': 'routine-task-walk',
        'afternoon_puzzle': 'routine-task-puzzle',
        'evening_audio': 'routine-task-audio'
    };

    let completedCount = 0;
    for (let key in taskMap) {
        const el = document.getElementById(taskMap[key]);
        if (el) {
            if (data[key]) {
                el.classList.add('done');
                completedCount++;
            } else {
                el.classList.remove('done');
            }
        }
    }

    // Hydration glass text
    const waterDesc = document.getElementById('routine-water-desc');
    if (waterDesc) {
        waterDesc.innerHTML = `11:00 AM &bull; ${data.water_count} / 6 Glasses Tracked Today`;
    }

    // Progress counter and bar
    const progText = document.getElementById('routine-progress-text');
    if (progText) {
        progText.innerText = `${completedCount} / 5 Completed`;
    }

    const progBar = document.getElementById('routine-progress-bar');
    if (progBar) {
        progBar.style.width = `${(completedCount / 5) * 100}%`;
    }
}

function markRoutineTaskDone(taskKey) {
    const data = getRoutineData();
    data[taskKey] = true;
    saveRoutineData(data);
    initRoutineScreen();
    playGentleChime();
}

function resetRoutineTasks() {
    const fresh = { ...DEFAULT_ROUTINE, date: new Date().toDateString() };
    saveRoutineData(fresh);
    initRoutineScreen();
    playGentleChime();
}

// --- ETHICAL MODAL & INTERACTION HANDLERS ---

function handleRoutineClick(taskKey) {
    const data = getRoutineData();
    
    if (taskKey === 'morning_brain') {
        showRoutineActionModal({
            icon: '&#x1F9E0;',
            badge: 'Prospective Memory Check',
            title: 'Morning Brain Warmup',
            desc: '<strong>Active Retrieval Practice:</strong> Take 10 seconds to recall: What day is today, and what is one goal you have? Actively retrieving memories primes your prefrontal cortex before playing your warmup game.',
            isDone: data.morning_brain,
            primaryBtnText: 'Play Quick Memory Game &#x25B6;',
            onPrimary: () => {
                closeRoutineModal();
                window.routineTaskCallback = () => {
                    markRoutineTaskDone('morning_brain');
                    showScreen('routine-screen');
                    showRoutineCongrats('Brain Warmup Complete! Great job actively challenging your working memory.');
                };
                startSingleGame(0); // Sequence Memory
            },
            onOffline: () => {
                closeRoutineModal();
                markRoutineTaskDone('morning_brain');
                showRoutineCongrats('Memory check-in logged! Daily self-recall keeps neural pathways active.');
            }
        });
    } else if (taskKey === 'hydration') {
        showHydrationModal();
    } else if (taskKey === 'walk') {
        showRoutineActionModal({
            icon: '&#x1F6B6;',
            badge: 'Mental Navigation & Movement',
            title: 'Gentle Walk & Movement',
            desc: '<strong>Spatial Recall Exercise:</strong> Can you mentally picture the route of your walk or garden stroll? Mental navigation exercises the parietal and hippocampal regions of the brain.',
            isDone: data.walk,
            primaryBtnText: 'Start Walk Tracker &#x25B6;',
            onPrimary: () => {
                closeRoutineModal();
                showScreen('walk-screen');
            },
            onOffline: () => {
                closeRoutineModal();
                markRoutineTaskDone('walk');
                showRoutineCongrats('Movement logged! Light movement increases oxygen and blood flow to memory centers.');
            }
        });
    } else if (taskKey === 'afternoon_puzzle') {
        showRoutineActionModal({
            icon: '&#x1F9E9;',
            badge: 'Working Memory Refresh',
            title: 'Afternoon Mind Refresh',
            desc: '<strong>Visual Recognition Check:</strong> A quick, relaxing matching game to counteract afternoon fatigue and train visual attention.',
            isDone: data.afternoon_puzzle,
            primaryBtnText: 'Play Quick Match &#x25B6;',
            onPrimary: () => {
                closeRoutineModal();
                window.routineTaskCallback = () => {
                    markRoutineTaskDone('afternoon_puzzle');
                    showScreen('routine-screen');
                    showRoutineCongrats('Afternoon Refresh Complete! Active visual discrimination strengthens memory.');
                };
                startSingleGame(4); // Animal Quick Match
            },
            onOffline: () => {
                closeRoutineModal();
                markRoutineTaskDone('afternoon_puzzle');
                showRoutineCongrats('Logged! Taking time for mental stimulation keeps the day balanced.');
            }
        });
    } else if (taskKey === 'evening_audio') {
        showAudioTherapyModal();
    }
}

function closeRoutineModal() {
    const existing = document.getElementById('routine-action-modal');
    if (existing) existing.remove();
}

function showRoutineActionModal(config) {
    closeRoutineModal();

    const modal = document.createElement('div');
    modal.id = 'routine-action-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0'; modal.style.left = '0';
    modal.style.width = '100vw'; modal.style.height = '100vh';
    modal.style.background = 'rgba(0,0,0,0.6)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10000';
    modal.style.animation = 'fadeIn 0.2s ease-out';

    modal.innerHTML = `
        <div style="background: white; border-radius: 24px; padding: 26px 22px; width: 90%; max-width: 380px; text-align: center; box-shadow: 0 15px 35px rgba(0,0,0,0.25);">
            <div style="display: inline-flex; align-items: center; gap: 6px; background: #E0F2F1; color: #00796B; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; margin-bottom: 12px;">
                <span class="material-symbols-rounded" style="font-size: 15px;">psychology</span> ${config.badge || 'Cognitive Scaffolding'}
            </div>
            
            <div style="font-size: 48px; margin-bottom: 8px;">${config.icon}</div>
            <h2 style="color: #37474F; font-size: 21px; margin: 0 0 8px 0; font-weight: 800;">${config.title}</h2>
            <p style="color: #555; font-size: 13.5px; margin: 0 0 20px 0; line-height: 1.5;">${config.desc}</p>
            
            ${config.isDone ? `
                <div style="background: #E8F5E9; color: #2E7D32; padding: 10px; border-radius: 14px; font-weight: bold; margin-bottom: 16px; font-size: 14px;">
                    &#x2705; Already completed for today!
                </div>
            ` : ''}

            <div style="display: flex; flex-direction: column; gap: 10px;">
                <button id="routine-modal-primary" style="background: #00796B; color: white; border: none; padding: 15px; font-size: 16px; font-weight: bold; border-radius: 16px; cursor: pointer; box-shadow: 0 4px 10px rgba(0,121,107,0.3);">
                    ${config.primaryBtnText}
                </button>
                
                <button id="routine-modal-offline" style="background: #F1F8E9; border: 2px solid #81C784; color: #2E7D32; padding: 13px; font-size: 14px; font-weight: 700; border-radius: 16px; cursor: pointer;">
                    &#x2714; Mark as Done (Self-Reflected Offline)
                </button>
                
                <button onclick="closeRoutineModal()" style="background: none; border: none; color: #90A4AE; padding: 8px; font-size: 13px; cursor: pointer;">
                    Close
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('routine-modal-primary').onclick = config.onPrimary;
    document.getElementById('routine-modal-offline').onclick = config.onOffline;
}

// --- COGNITIVE SCAFFOLDING HYDRATION RECALL MODAL ---

function showHydrationModal() {
    closeRoutineModal();
    const data = getRoutineData();

    const modal = document.createElement('div');
    modal.id = 'routine-action-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0'; modal.style.left = '0';
    modal.style.width = '100vw'; modal.style.height = '100vh';
    modal.style.background = 'rgba(0,0,0,0.6)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10000';

    modal.innerHTML = `
        <div style="background: white; border-radius: 24px; padding: 26px 20px; width: 90%; max-width: 380px; text-align: center; box-shadow: 0 15px 35px rgba(0,0,0,0.25);">
            <div style="display: inline-flex; align-items: center; gap: 6px; background: #E0F2F1; color: #00796B; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; margin-bottom: 10px;">
                <span class="material-symbols-rounded" style="font-size: 15px;">psychology</span> Active Recall Check
            </div>
            
            <div style="font-size: 44px; margin-bottom: 4px;">&#x1F4A7;</div>
            <h2 style="color: #0277BD; font-size: 21px; margin: 0 0 6px 0; font-weight: 800;">Hydration & Memory</h2>
            <p style="color: #555; font-size: 13.5px; margin: 0 0 16px 0; line-height: 1.4;">
                <strong>Test your recent memory:</strong> Can you recall when you last drank a glass of water today?
            </p>

            <!-- Active Retrieval Buttons -->
            <div id="recall-options-box" style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 14px;">
                <button class="recall-btn" onclick="submitHydrationRecall('recent', this)" style="background: #F1F8E9; border: 2px solid #AED581; color: #33691E; padding: 11px 14px; border-radius: 12px; font-size: 13.5px; font-weight: 600; cursor: pointer; text-align: left; transition: 0.2s;">
                    &#x2600;&#xFE0F; Recently (Past 1-2 hours)
                </button>
                <button class="recall-btn" onclick="submitHydrationRecall('meal', this)" style="background: #FFF8E1; border: 2px solid #FFE082; color: #F57F17; padding: 11px 14px; border-radius: 12px; font-size: 13.5px; font-weight: 600; cursor: pointer; text-align: left; transition: 0.2s;">
                    &#x1F374; Around mealtime earlier
                </button>
                <button class="recall-btn" onclick="submitHydrationRecall('not_sure', this)" style="background: #E3F2FD; border: 2px solid #90CAF9; color: #0D47A1; padding: 11px 14px; border-radius: 12px; font-size: 13.5px; font-weight: 600; cursor: pointer; text-align: left; transition: 0.2s;">
                    &#x1F914; Not sure / Need a fresh glass now!
                </button>
            </div>

            <!-- Recall Feedback Box -->
            <div id="recall-feedback-box" style="display: none; background: #E8F5E9; border: 1px solid #A5D6A7; border-radius: 12px; padding: 10px 12px; margin-bottom: 14px; font-size: 12.5px; color: #2E7D32; line-height: 1.4; text-align: left;">
                <strong>&#x1F9E0; Brain Stimulated!</strong> Actively reflecting on recent events exercises your episodic memory and strengthens hippocampal recall.
            </div>
            
            <div style="background: #F1F8E9; border-radius: 14px; padding: 10px 14px; margin-bottom: 14px; border: 1px solid #C5E1A5; display: flex; justify-content: space-between; align-items: center;">
                <span style="font-size: 13px; color: #33691E; font-weight: 700;">Glasses Tracked Today:</span>
                <span id="modal-water-count" style="font-size: 20px; font-weight: 800; color: #0277BD;">${data.water_count} / 6</span>
            </div>

            <div style="display: flex; flex-direction: column; gap: 10px;">
                <button id="btn-drink-water" style="background: linear-gradient(135deg, #0288D1, #01579B); color: white; border: none; padding: 14px; font-size: 16px; font-weight: bold; border-radius: 16px; cursor: pointer; box-shadow: 0 4px 10px rgba(2,136,209,0.3);">
                    &#x1F4A7; Log Glass & Check Off Task
                </button>
                
                <button onclick="closeRoutineModal()" style="background: none; border: none; color: #90A4AE; padding: 6px; font-size: 13px; cursor: pointer;">
                    Close
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById('btn-drink-water').onclick = () => {
        const cur = getRoutineData();
        cur.water_count = (cur.water_count || 0) + 1;
        cur.hydration = true;
        saveRoutineData(cur);
        initRoutineScreen();
        playGentleWaterDropSound();
        closeRoutineModal();
        showRoutineCongrats('Recall & Hydration Tracked! Self-reflection and hydration both keep your brain resilient.');
    };
}

function submitHydrationRecall(choice, btn) {
    document.querySelectorAll('.recall-btn').forEach(b => {
        b.style.opacity = '0.4';
        b.style.pointerEvents = 'none';
    });
    btn.style.opacity = '1';
    btn.style.borderColor = '#2E7D32';
    btn.style.borderWidth = '3px';
    const fb = document.getElementById('recall-feedback-box');
    if (fb) {
        fb.style.display = 'block';
        playGentleChime();
    }
}


// --- AUDIO THERAPY & CALMING SOUNDSCAPE MODULE ---

let activeAudioNodes = null;
let breathingInterval = null;

function showAudioTherapyModal() {
    closeRoutineModal();
    const data = getRoutineData();

    const modal = document.createElement('div');
    modal.id = 'routine-action-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0'; modal.style.left = '0';
    modal.style.width = '100vw'; modal.style.height = '100vh';
    modal.style.background = 'rgba(10, 25, 47, 0.85)';
    modal.style.backdropFilter = 'blur(8px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10000';

    modal.innerHTML = `
        <div style="background: #1A2B42; color: white; border-radius: 28px; padding: 30px 22px; width: 92%; max-width: 400px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.1);">
            <div style="font-size: 40px; margin-bottom: 6px;">&#x1F3A7;</div>
            <h2 style="color: #90CAF9; font-size: 22px; margin: 0 0 6px 0; font-weight: 800;">Evening Audio Therapy</h2>
            <p style="color: #B0BEC5; font-size: 13px; margin: 0 0 20px 0;">Soothing soundscapes & guided breathing to ease evening restlessness and support deep sleep.</p>

            <!-- Breathing Circle -->
            <div style="position: relative; width: 170px; height: 170px; margin: 0 auto 24px; display: flex; align-items: center; justify-content: center;">
                <div id="breathing-ring" style="position: absolute; width: 120px; height: 120px; border-radius: 50%; background: radial-gradient(circle, rgba(100,181,246,0.35) 0%, rgba(30,136,229,0.1) 70%); border: 3px solid #64B5F6; transition: 4s ease-in-out;"></div>
                <div id="breathing-text" style="position: relative; z-index: 2; font-size: 17px; font-weight: 700; color: white;">Breathe In</div>
            </div>

            <!-- Sound Selection -->
            <div style="display: flex; gap: 8px; justify-content: center; margin-bottom: 22px;">
                <button class="sound-chip active-chip" onclick="switchSoundscape('rain', this)" style="background: #283E58; color: #90CAF9; border: 1px solid #64B5F6; padding: 8px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer;">
                    &#x1F327;&#xFE0F; Rain
                </button>
                <button class="sound-chip" onclick="switchSoundscape('bowl', this)" style="background: #283E58; color: #B0BEC5; border: 1px solid rgba(255,255,255,0.15); padding: 8px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer;">
                    &#x1F9D8; Singing Bowl
                </button>
                <button class="sound-chip" onclick="switchSoundscape('flute', this)" style="background: #283E58; color: #B0BEC5; border: 1px solid rgba(255,255,255,0.15); padding: 8px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer;">
                    &#x1FA84; Flute Drone
                </button>
            </div>

            <!-- Audio Toggle & Complete -->
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <button id="btn-toggle-sound" onclick="toggleSoundscapePlay()" style="background: #0288D1; color: white; border: none; padding: 15px; font-size: 16px; font-weight: bold; border-radius: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span id="sound-play-icon">&#x25B6;</span> <span id="sound-play-text">Start Calming Soundscape</span>
                </button>

                <button onclick="finishAudioTherapySession()" style="background: linear-gradient(135deg, #4CAF50, #2E7D32); color: white; border: none; padding: 15px; font-size: 16px; font-weight: bold; border-radius: 16px; cursor: pointer; box-shadow: 0 4px 10px rgba(76,175,80,0.3);">
                    &#x2714; Complete Session & Mark Done
                </button>

                <button onclick="closeAudioTherapyModal()" style="background: none; border: none; color: #90A4AE; padding: 8px; font-size: 13px; cursor: pointer;">
                    Exit
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    startBreathingAnimation();
}

function closeAudioTherapyModal() {
    stopSoundscape();
    if (breathingInterval) clearInterval(breathingInterval);
    closeRoutineModal();
}

function finishAudioTherapySession() {
    stopSoundscape();
    if (breathingInterval) clearInterval(breathingInterval);
    closeRoutineModal();
    markRoutineTaskDone('evening_audio');
    showRoutineCongrats('Evening Relaxation Complete! May you have a peaceful, deep, and restful night.');
}

function startBreathingAnimation() {
    if (breathingInterval) clearInterval(breathingInterval);
    const ring = document.getElementById('breathing-ring');
    const text = document.getElementById('breathing-text');
    if (!ring || !text) return;

    let state = 0; // 0: inhale (4s), 1: hold (2s), 2: exhale (4s), 3: rest (2s)
    function cycle() {
        if (!document.getElementById('breathing-ring')) {
            clearInterval(breathingInterval);
            return;
        }
        if (state === 0) {
            text.innerText = 'Breathe In...';
            ring.style.transform = 'scale(1.4)';
            ring.style.opacity = '1';
            setTimeout(cycle, 4000);
            state = 1;
        } else if (state === 1) {
            text.innerText = 'Hold Gently...';
            setTimeout(cycle, 2000);
            state = 2;
        } else if (state === 2) {
            text.innerText = 'Slowly Breathe Out...';
            ring.style.transform = 'scale(1.0)';
            ring.style.opacity = '0.6';
            setTimeout(cycle, 4000);
            state = 3;
        } else {
            text.innerText = 'Rest...';
            setTimeout(cycle, 2000);
            state = 0;
        }
    }
    cycle();
}

// --- WEB AUDIO API REAL-TIME SYNTHESIS (Zero External File Dependencies) ---
let audioCtx = null;
let currentSoundType = 'rain';
let isSoundPlaying = false;

function getAudioContext() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    return audioCtx;
}

function switchSoundscape(type, btn) {
    currentSoundType = type;
    document.querySelectorAll('.sound-chip').forEach(b => {
        b.style.color = '#B0BEC5';
        b.style.borderColor = 'rgba(255,255,255,0.15)';
    });
    if (btn) {
        btn.style.color = '#90CAF9';
        btn.style.borderColor = '#64B5F6';
    }
    if (isSoundPlaying) {
        stopSoundscape();
        startSoundscape(currentSoundType);
    }
}

function toggleSoundscapePlay() {
    if (isSoundPlaying) {
        stopSoundscape();
        const icon = document.getElementById('sound-play-icon');
        const text = document.getElementById('sound-play-text');
        if (icon) icon.innerText = '&#x25B6;';
        if (text) text.innerText = 'Start Calming Soundscape';
    } else {
        startSoundscape(currentSoundType);
        const icon = document.getElementById('sound-play-icon');
        const text = document.getElementById('sound-play-text');
        if (icon) icon.innerText = '&#x23F8;';
        if (text) text.innerText = 'Pause Soundscape';
    }
}

function startSoundscape(type) {
    try {
        const ctx = getAudioContext();
        stopSoundscape();
        isSoundPlaying = true;

        if (type === 'rain') {
            // Synthesized Pink Noise with low-pass filter
            const bufferSize = ctx.sampleRate * 2;
            const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
            const output = noiseBuffer.getChannelData(0);
            let b0 = 0, b1 = 0, b2 = 0;
            for (let i = 0; i < bufferSize; i++) {
                let white = Math.random() * 2 - 1;
                b0 = 0.99886 * b0 + white * 0.0555179;
                b1 = 0.99332 * b1 + white * 0.0750759;
                b2 = 0.96900 * b2 + white * 0.1538520;
                output[i] = (b0 + b1 + b2) * 0.08;
            }
            const whiteNoise = ctx.createBufferSource();
            whiteNoise.buffer = noiseBuffer;
            whiteNoise.loop = true;

            const filter = ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.value = 800;

            const gain = ctx.createGain();
            gain.gain.setValueAtTime(0.01, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 1.5);

            whiteNoise.connect(filter);
            filter.connect(gain);
            gain.connect(ctx.destination);
            whiteNoise.start();

            activeAudioNodes = { source: whiteNoise, gain: gain };
        } else if (type === 'bowl') {
            // Harmonic Singing Bowl tones (216Hz, 432Hz)
            const osc1 = ctx.createOscillator();
            const osc2 = ctx.createOscillator();
            const gain = ctx.createGain();

            osc1.type = 'sine'; osc1.frequency.setValueAtTime(216, ctx.currentTime);
            osc2.type = 'sine'; osc2.frequency.setValueAtTime(432, ctx.currentTime);

            gain.gain.setValueAtTime(0.01, ctx.currentTime);
            gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + 1.2);

            osc1.connect(gain);
            osc2.connect(gain);
            gain.connect(ctx.destination);
            osc1.start();
            osc2.start();

            activeAudioNodes = { source: osc1, source2: osc2, gain: gain };
        } else if (type === 'flute') {
            // Warm Tanpura / Meditative Flute Drone (144Hz with gentle tremolo)
            const osc = ctx.createOscillator();
            const lfo = ctx.createOscillator();
            const lfoGain = ctx.createGain();
            const gain = ctx.createGain();

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(144, ctx.currentTime);

            lfo.frequency.setValueAtTime(4.5, ctx.currentTime);
            lfoGain.gain.setValueAtTime(2.5, ctx.currentTime);
            lfo.connect(osc.frequency);

            gain.gain.setValueAtTime(0.01, ctx.currentTime);
            gain.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 1.5);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start();
            lfo.start();

            activeAudioNodes = { source: osc, lfo: lfo, gain: gain };
        }
    } catch(e) {
        console.log('Audio Context Error:', e);
    }
}

function stopSoundscape() {
    isSoundPlaying = false;
    if (activeAudioNodes && audioCtx) {
        try {
            if (activeAudioNodes.gain) {
                activeAudioNodes.gain.gain.linearRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
            }
            setTimeout(() => {
                if (activeAudioNodes && activeAudioNodes.source) {
                    try { activeAudioNodes.source.stop(); } catch(e) {}
                }
                if (activeAudioNodes && activeAudioNodes.source2) {
                    try { activeAudioNodes.source2.stop(); } catch(e) {}
                }
                if (activeAudioNodes && activeAudioNodes.lfo) {
                    try { activeAudioNodes.lfo.stop(); } catch(e) {}
                }
                activeAudioNodes = null;
            }, 350);
        } catch(e) {
            activeAudioNodes = null;
        }
    }
}

function playGentleChime() {
    try {
        const ctx = getAudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(528, ctx.currentTime); // 528Hz Solfeggio Love/Healing tone
        osc.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.15);

        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.9);
    } catch(e) {}
}

function playGentleWaterDropSound() {
    try {
        const ctx = getAudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.1);

        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
    } catch(e) {}
}

function showRoutineCongrats(message) {
    const existing = document.getElementById('routine-congrats-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'routine-congrats-modal';
    modal.style.position = 'fixed';
    modal.style.top = '0'; modal.style.left = '0';
    modal.style.width = '100vw'; modal.style.height = '100vh';
    modal.style.background = 'rgba(0,0,0,0.6)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10001';
    modal.style.animation = 'fadeIn 0.2s ease-out';

    modal.innerHTML = `
        <div style="background: white; border-radius: 24px; padding: 28px 24px; width: 90%; max-width: 380px; text-align: center; box-shadow: 0 15px 35px rgba(0,0,0,0.25);">
            <div style="font-size: 55px; margin-bottom: 12px;">&#x1F31F;</div>
            <h2 style="color: #00796B; font-size: 22px; margin: 0 0 8px 0; font-weight: 800;">Wonderful Progress!</h2>
            <p style="color: #555; font-size: 15px; margin: 0 0 22px 0; line-height: 1.5;">${message}</p>
            
            <button onclick="document.getElementById('routine-congrats-modal').remove()" style="background: #00796B; color: white; border: none; padding: 14px 28px; font-size: 16px; font-weight: bold; border-radius: 24px; cursor: pointer; width: 100%; box-shadow: 0 4px 10px rgba(0,121,107,0.3);">
                Continue Routine &#x2714;
            </button>
        </div>
    `;

    document.body.appendChild(modal);
}
